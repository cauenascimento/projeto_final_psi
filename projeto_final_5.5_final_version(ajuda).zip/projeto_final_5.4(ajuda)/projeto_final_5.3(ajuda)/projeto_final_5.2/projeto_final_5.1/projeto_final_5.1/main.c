#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>  // Biblioteca para getch()
#include <windows.h>
#include <conio.c>
#include <locale.h>
#include <string.h>
#include "info_clubs.h"
#include "champ22_23.h"
#include "noespaco.h"

#define MAX_USERS 20
#define MAX_NAME 50
#define MAX_PASSWORD 20
#define FILE_NAME "users.txt"
#define NUM_CLUBES 16


// Estrutura para representar um clube
typedef struct
{
    char nome[50];
} Clube;

// Fun��o para realizar um jogo e determinar o vencedor
int realizarJogo(Clube clubeA, Clube clubeB)
{
    //armazena o resultado do jogo
    int resultado;
    //string de at� 100 caracteres para capturar a entrada do usu�rio.
    char fim[100];


    printf("Resultado do jogo entre %s e %s:\n", clubeA.nome, clubeB.nome);
    do {
        printf("Digite 1 para vit�ria de %s ou 2 para vit�ria de %s: ", clubeA.nome, clubeB.nome);
        scanf("%s", fim);
        //converte a string fim em um valor inteiro. O resultado da convers�o � atribu�do � vari�vel resultado.
        resultado = atoi(fim);

        if (resultado != 1 && resultado != 2)
            {
                textcolor(RED);
            printf("Op��o inv�lida. Tente novamente.\n");
            textcolor(WHITE);
        }
        //verifica se o resultado digitado � diferente de '1' e diferente de '2'. Se a condi��o for verdadeira, significa que a entrada � inv�lida e uma mensagem de erro � exibida no ecran
    } while (resultado != 1 && resultado != 2);

    return resultado;
}



struct User
{
    char name[MAX_NAME];
    char password[MAX_PASSWORD];
};

struct User users[MAX_USERS];
int numUsers = 0;

// Fun��o para registrar um novo usu�rio
void registerUser()
{
    // Verifica se o limite m�ximo de usu�rios foi atingido
    if (numUsers >= MAX_USERS)
    {
        system("cls");
        textcolor(RED);
        printf("O limite m�ximo de usu�rios foi atingido.\n");
        return;
    }

    struct User newUser;
             textcolor(BLUE);
    printf(R"EOF(
                                                                               _____ _    _          __  __ _____ _____ ____  _   _  _____
                                                                              / ____| |  | |   /\   |  \/  |  __ \_   _/ __ \| \ | |/ ____|
                                                                             | |    | |__| |  /  \  | \  / | |__) || || |  | |  \| | (___
                                                                             | |    |  __  | / /\ \ | |\/| |  ___/ | || |  | | . ` |\___ \
                                                                             | |____| |  | |/ ____ \| |  | | |    _| || |__| | |\  |____) |
                                                                              \_____|_|  |_/_/    \_\_|  |_|_|   |_____\____/|_| \_|_____/

                                                           _____   ____          _____    _______ ____    _______ _    _ ______   ______ _____ _   _          _
                                                          |  __ \ / __ \   /\   |  __ \  |__   __/ __ \  |__   __| |  | |  ____| |  ____|_   _| \ | |   /\   | |
                                                          | |__) | |  | | /  \  | |  | |    | | | |  | |    | |  | |__| | |__    | |__    | | |  \| |  /  \  | |
                                                          |  _  /| |  | |/ /\ \ | |  | |    | | | |  | |    | |  |  __  |  __|   |  __|   | | | . ` | / /\ \ | |
                                                          | | \ \| |__| / ____ \| |__| |    | | | |__| |    | |  | |  | | |____  | |     _| |_| |\  |/ ____ \| |____
                                                          |_|  \_\\____/_/    \_\_____/     |_|  \____/     |_|  |_|  |_|______| |_|    |_____|_| \_/_/    \_\______|


)EOF");
textcolor(WHITE);
    // Verifica e solicita o nome de usu�rio sem espa�os
    printf("Digite o nome de usu�rio: ");
    scanf("%s", newUser.name);

    // Verifica se o nome de usu�rio cont�m espa�os
    while (strchr(newUser.name, ' ') != NULL) {
        system("cls");
        textcolor(RED);
        printf("Nome de usu�rio inv�lido. N�o � permitido usar espa�os.\n");

        printf("Digite o nome de usu�rio: ");
        scanf("%s", newUser.name);
    }


    // Verifica se o nome de usu�rio j� existe
    for (int i = 0; i < numUsers; i++)
        {
        if (strcmp(users[i].name, newUser.name) == 0)
        {
            system("cls");
            textcolor(RED);
            printf("Nome de usu�rio j� existe. Tente novamente.\n");
            return;
        }
    }

      // Verifica e solicita a senha sem espa�os
    printf("Digite a senha: ");
    scanf("%s", newUser.password);

    // Verifica se a senha cont�m espa�os
    while (strchr(newUser.password, ' ') != NULL) {
        system("cls");
        textcolor(RED);
        printf("Senha inv�lida. N�o � permitido usar espa�os.\n");

        printf("Digite a senha: ");
        scanf("%s", newUser.password);
    }
    users[numUsers] = newUser;
    numUsers++;

    // Salvar o usu�rio no arquivo
    FILE* file = fopen(FILE_NAME, "a");
    if (file != NULL)
    {
        fprintf(file, "%s %s\n", newUser.name, newUser.password);
        fclose(file);
    }
system("cls");
textcolor(GREEN);
    printf("Registro conclu�do com sucesso.\n");
}

// Fun��o para carregar os usu�rios do arquivo
void loadUsers()
{
    FILE* file = fopen(FILE_NAME, "r");
    if (file != NULL)
        {
        char name[MAX_NAME];
        char password[MAX_PASSWORD];

        while (fscanf(file, "%s %s\n", name, password) == 2)
            {
            struct User newUser;
            strcpy(newUser.name, name);
            strcpy(newUser.password, password);
            users[numUsers] = newUser;
            numUsers++;
        }

        fclose(file);
    }
}

// Fun��o para realizar o login do usu�rio
void login()
{
    char name[MAX_NAME];
    char password[MAX_PASSWORD];
    int info;
             textcolor(BLUE);
    printf(R"EOF(
                                                                               _____ _    _          __  __ _____ _____ ____  _   _  _____
                                                                              / ____| |  | |   /\   |  \/  |  __ \_   _/ __ \| \ | |/ ____|
                                                                             | |    | |__| |  /  \  | \  / | |__) || || |  | |  \| | (___
                                                                             | |    |  __  | / /\ \ | |\/| |  ___/ | || |  | | . ` |\___ \
                                                                             | |____| |  | |/ ____ \| |  | | |    _| || |__| | |\  |____) |
                                                                              \_____|_|  |_/_/    \_\_|  |_|_|   |_____\____/|_| \_|_____/

                                                           _____   ____          _____    _______ ____    _______ _    _ ______   ______ _____ _   _          _
                                                          |  __ \ / __ \   /\   |  __ \  |__   __/ __ \  |__   __| |  | |  ____| |  ____|_   _| \ | |   /\   | |
                                                          | |__) | |  | | /  \  | |  | |    | | | |  | |    | |  | |__| | |__    | |__    | | |  \| |  /  \  | |
                                                          |  _  /| |  | |/ /\ \ | |  | |    | | | |  | |    | |  |  __  |  __|   |  __|   | | | . ` | / /\ \ | |
                                                          | | \ \| |__| / ____ \| |__| |    | | | |__| |    | |  | |  | | |____  | |     _| |_| |\  |/ ____ \| |____
                                                          |_|  \_\\____/_/    \_\_____/     |_|  \____/     |_|  |_|  |_|______| |_|    |_____|_| \_/_/    \_\______|


)EOF");
textcolor(WHITE);

    printf("Digite o nome de usu�rio: ");
    scanf("%s", name);

    printf("Digite a senha: ");
    scanf("%s", password);
    system("cls");

    // Verifica se o nome de usu�rio e senha correspondem a um usu�rio registrado
    for (int i = 0; i < numUsers; i++)
    {
        if (strcmp(users[i].name, name) == 0 && strcmp(users[i].password, password) == 0)
            {
                textcolor(BLUE);
    printf(R"EOF(
                                                                               _____ _    _          __  __ _____ _____ ____  _   _  _____
                                                                              / ____| |  | |   /\   |  \/  |  __ \_   _/ __ \| \ | |/ ____|
                                                                             | |    | |__| |  /  \  | \  / | |__) || || |  | |  \| | (___
                                                                             | |    |  __  | / /\ \ | |\/| |  ___/ | || |  | | . ` |\___ \
                                                                             | |____| |  | |/ ____ \| |  | | |    _| || |__| | |\  |____) |
                                                                              \_____|_|  |_/_/    \_\_|  |_|_|   |_____\____/|_| \_|_____/

                                                           _____   ____          _____    _______ ____    _______ _    _ ______   ______ _____ _   _          _
                                                          |  __ \ / __ \   /\   |  __ \  |__   __/ __ \  |__   __| |  | |  ____| |  ____|_   _| \ | |   /\   | |
                                                          | |__) | |  | | /  \  | |  | |    | | | |  | |    | |  | |__| | |__    | |__    | | |  \| |  /  \  | |
                                                          |  _  /| |  | |/ /\ \ | |  | |    | | | |  | |    | |  |  __  |  __|   |  __|   | | | . ` | / /\ \ | |
                                                          | | \ \| |__| / ____ \| |__| |    | | | |__| |    | |  | |  | | |____  | |     _| |_| |\  |/ ____ \| |____
                                                          |_|  \_\\____/_/    \_\_____/     |_|  \____/     |_|  |_|  |_|______| |_|    |_____|_| \_/_/    \_\______|


)EOF");
textcolor(GREEN);

            printf("Login bem-sucedido. Bem-vindo, %s!\n", users[i].name);
textcolor(WHITE);

            char menuChoice;
            char buss;
            do {
                printf("\n==== Menu ====\n");
                printf("1. Champions 22/23\n");
                printf("2. Informa��es dos Clubes\n");
                printf("3. Criar uma Champions\n");
                printf("4. Hist�rico\n");
                printf("0. Sair da Conta\n");
                printf("Escolha uma op��o: ");
                scanf(" %c", &menuChoice);
                fflush(stdin);
                system("cls");

                switch (menuChoice)
                {
                    case '1':
                        textcolor(GREEN);
                        printf("Executando Champions 22/23.\n");
                        champ();

                        break;
                    case '2':
                        textcolor(GREEN);
                        printf("Executando Informa��es de Clubes.\n");
                        textcolor(WHITE);
                        printf("Lista de clubes com hist�rico na UEFA Champions League:\n");
                         printf("\n");
                        printf("1� - Real Madrid - 14 T�tulos da UCL\n");
                         printf("\n");
                        printf("2� - Milan - 7 T�tulos da UCL\n");
                         printf("\n");
                        printf("3� - Bayern de Munique - 6 T�tulos da UCL\n");
                         printf("\n");
                        printf("4� - Liverpool - 6 T�tulos da UCL\n");
                         printf("\n");
                        printf("5� - Barcelona - 5 T�tulos da UCL\n");
                         printf("\n");
                        printf("6� - Ajax - 4 T�tulos da UCL\n");
                         printf("\n");
                        printf("7� - Manchester United - 3 T�tulos da UCL\n");
                         printf("\n");
                        printf("8� - Inter de Mil�o - 3 T�tulos da UCL\n");
                         printf("\n");
                        printf("9� - Chealsea - 2 T�tulos da UCL\n");
                         printf("\n");
                        printf("10� - Nottingham Forest - 2 T�tulos da UCL\n");
                         printf("\n");
                        printf("11� - Benfica - 2 T�tulos da UCL\n");
                         printf("\n");
                        printf("12� - Juventus - 2 T�tulos da UCL\n");
                         printf("\n");
                        printf("13� - Porto - 2 T�tulos da UCL\n");
                         printf("\n");
                        printf("14� - Borussia Dortmund - 1 T�tulos da UCL\n");
                         printf("\n");
                        printf("15� - Feyemoord - 1 T�tulos da UCL\n");
                         printf("\n");
                        printf("16� - Marseille - 1 T�tulos da UCL\n");
                         printf("\n");
                        printf("17� - Aston Villa - 1 T�tulos da UCL\n");
                         printf("\n");
                        printf("18� - Hamburg - 1 T�tulos da UCL\n");
                         printf("\n");
                        printf("19� - Crvena Zvezda - 1 T�tulos da UCL\n");
                         printf("\n");
                        printf("20� - FCSB - 1 T�tulos da UCL\n");
                         printf("\n");
                        printf("21� - PSV - 1 T�tulos da UCL\n");
                        printf("\n");
                        printf("22� - Celtic - 1 T�tulos da UCL\n");
                        printf("\n");
                        printf("23� - Manchester City - 1 T�tulos da UCL\n");
                        printf("\n");
                        printf("Insira o Numero do clube que deseja saber mais: ");
                        scanf("%i", &info);
                        fflush(stdin);
                        while (1){
                            if (info >= 1 && info <= 23){
                            system("cls");
                            infoclub(info);
                            break;
                        } else{
                            printf("\nValor inv�lido, tente novamente: ");
                            scanf("%d", &info);
                            fflush(stdin);
                            }
                        }



                        break;
                    case '3':
                        textcolor(GREEN);
                        printf("Executando Criar Champions league.\n");
                        //cria um array para armazenar o nome dos clubes
                            Clube clubes[NUM_CLUBES];

    // Preenchendo os nomes dos clubes
     textcolor(YELLOW);
    printf(R"EOF(


     ______   ________  __        ________   ______    ______    ______         _______    ______    ______          ______   __        __    __  _______   ________   ______
    /      \ /        |/  |      /        | /      \  /      \  /      \       /       \  /      \  /      \        /      \ /  |      /  |  /  |/       \ /        | /      \
   $$$$$$$  |$$$$$$$$/ $$ |      $$$$$$$$/ /$$$$$$  |/$$$$$$  |/$$$$$$  |      $$$$$$$  |/$$$$$$  |/$$$$$$  |      /$$$$$$  |$$ |      $$ |  $$ |$$$$$$$  |$$$$$$$$/ /$$$$$$  |
   $$ \__$$/ $$ |__    $$ |      $$ |__    $$ |  $$/ $$ |__$$ |$$ |  $$ |      $$ |  $$ |$$ |  $$ |$$ \__$$/       $$ |  $$/ $$ |      $$ |  $$ |$$ |__$$ |$$ |__    $$ \__$$/
   $$      \ $$    |   $$ |      $$    |   $$ |      $$    $$ |$$ |  $$ |      $$ |  $$ |$$ |  $$ |$$      \       $$ |      $$ |      $$ |  $$ |$$    $$< $$    |   $$      \
    $$$$$$  |$$$$$/    $$ |      $$$$$/    $$ |   __ $$$$$$$$ |$$ |  $$ |      $$ |  $$ |$$ |  $$ | $$$$$$  |      $$ |   __ $$ |      $$ |  $$ |$$$$$$$  |$$$$$/     $$$$$$  |
   /  \__$$ |$$ |_____ $$ |_____ $$ |_____ $$ \__/  |$$ |  $$ |$$ \__$$ |      $$ |__$$ |$$ \__$$ |/  \__$$ |      $$ \__/  |$$ |_____ $$ \__$$ |$$ |__$$ |$$ |_____ /  \__$$ |
   $$    $$/ $$       |$$       |$$       |$$    $$/ $$ |  $$ |$$    $$/       $$    $$/ $$    $$/ $$    $$/       $$    $$/ $$       |$$    $$/ $$    $$/ $$       |$$    $$/
    $$$$$$/  $$$$$$$$/ $$$$$$$$/ $$$$$$$$/  $$$$$$/  $$/   $$/  $$$$$$/        $$$$$$$/   $$$$$$/   $$$$$$/         $$$$$$/  $$$$$$$$/  $$$$$$/  $$$$$$$/  $$$$$$$$/  $$$$$$/





)EOF");
textcolor(WHITE);
    printf("                === ESTE TORNEIO CONTEM 16 CLUBES � ESCOLHA DO USUARIO ===\n");
    printf("permitindo ao usuario escolher o nome das equipas, podendo at� mesmo por nomes aleat�rios!!!\n\n");
    //pedir 16 vezes o nome dos clubes
    for (int i = 0; i < NUM_CLUBES; i++) {
        printf("Digite o nome do clube %d: ", i + 1);
        //l� espa�os em branco
         scanf(" %[^\n]", clubes[i].nome);
         // Converter o nome para mai�sculas
        for (int j = 0; clubes[i].nome[j]; j++) {
            clubes[i].nome[j] = toupper(clubes[i].nome[j]);
        }

    }
system("cls");
    // Fase de Oitavas de Final
    textcolor(BLUE);
    printf(R"EOF(

   ______   ______  ________  ______   __     __   ______    ______         _______   ________        ________  ______  __    __   ______   __
  /      \ /      |/        |/      \ /  |   /  | /      \  /      \       /       \ /        |      /        |/      |/  \  /  | /      \ /  |
 /$$$$$$  |$$$$$$/ $$$$$$$$//$$$$$$  |$$ |   $$ |/$$$$$$  |/$$$$$$  |      $$$$$$$  |$$$$$$$$/       $$$$$$$$/ $$$$$$/ $$  \ $$ |/$$$$$$  |$$ |
 $$ |  $$ |  $$ |     $$ |  $$ |__$$ |$$ |   $$ |$$ |__$$ |$$ \__$$/       $$ |  $$ |$$ |__          $$ |__      $$ |  $$$  \$$ |$$ |__$$ |$$ |
 $$ |  $$ |  $$ |     $$ |  $$    $$ |$$  \ /$$/ $$    $$ |$$      \       $$ |  $$ |$$    |         $$    |     $$ |  $$$$  $$ |$$    $$ |$$ |
 $$ |  $$ |  $$ |     $$ |  $$$$$$$$ | $$  /$$/  $$$$$$$$ | $$$$$$  |      $$ |  $$ |$$$$$/          $$$$$/      $$ |  $$ $$ $$ |$$$$$$$$ |$$ |
 $$ \__$$ | _$$ |_    $$ |  $$ |  $$ |  $$ $$/   $$ |  $$ |/  \__$$ |      $$ |__$$ |$$ |_____       $$ |       _$$ |_ $$ |$$$$ |$$ |  $$ |$$ |_____
 $$    $$/ / $$   |   $$ |  $$ |  $$ |   $$$/    $$ |  $$ |$$    $$/       $$    $$/ $$       |      $$ |      / $$   |$$ | $$$ |$$ |  $$ |$$       |
  $$$$$$/  $$$$$$/    $$/   $$/   $$/     $/     $$/   $$/  $$$$$$/        $$$$$$$/  $$$$$$$$/       $$/       $$$$$$/ $$/   $$/ $$/   $$/ $$$$$$$$/






)EOF");
textcolor(WHITE);
//faz com que um clube da 1 metade da array se encontre com outro da 2 metade
    for (int i = 0; i < NUM_CLUBES / 2; i++)
        {
            //atribui o clube que est� em i para a variavel clubeA
        Clube clubeA = clubes[i];
    //O clube na posi��o complementar ao i � atribu�do � vari�vel clubeB. Isso � feito subtraindo 1 do n�mero total de clubes (NUM_CLUBES) e subtraindo i novamente para obter a posi��o correspondente na segunda metade do array.
        Clube clubeB = clubes[NUM_CLUBES - 1 - i];
// chama a fun��o realizarJogo passa pelas variaveis e realiza o jogo entreo os 2: 1 para clubeA, 2 para clubeB
        int vencedor = realizarJogo(clubeA, clubeB);
//Com base no vencedor retornado pela fun��o realizarJogo(), o clube vencedor � atribu�do � posi��o i do array clubes. Se o vencedor for 1, clubeA � atribu�do; caso contr�rio, clubeB
        clubes[i] = vencedor == 1 ? clubeA : clubeB;
        textcolor(YELLOW);
        printf("Vencedor da partida: %s\n\n", clubes[i].nome);
        textcolor(WHITE);
    }
system("cls");
    // Fase de Quartas de Final
    textcolor(BLUE);
    printf(R"EOF(


  ______   __    __   ______   _______   ________  ______    ______         _______   ________        ________  ______  __    __   ______   ______   ______
 /      \ /  |  /  | /      \ /       \ /        |/      \  /      \       /       \ /        |      /        |/      |/  \  /  | /      \ /      | /      \
/$$$$$$  |$$ |  $$ |/$$$$$$  |$$$$$$$  |$$$$$$$$//$$$$$$  |/$$$$$$  |      $$$$$$$  |$$$$$$$$/       $$$$$$$$/ $$$$$$/ $$  \ $$ |/$$$$$$  |$$$$$$/ /$$$$$$  |
$$ |  $$ |$$ |  $$ |$$ |__$$ |$$ |__$$ |   $$ |  $$ |__$$ |$$ \__$$/       $$ |  $$ |$$ |__          $$ |__      $$ |  $$$  \$$ |$$ |__$$ |  $$ |  $$ \__$$/
$$ |  $$ |$$ |  $$ |$$    $$ |$$    $$<    $$ |  $$    $$ |$$      \       $$ |  $$ |$$    |         $$    |     $$ |  $$$$  $$ |$$    $$ |  $$ |  $$      \
$$ |_ $$ |$$ |  $$ |$$$$$$$$ |$$$$$$$  |   $$ |  $$$$$$$$ | $$$$$$  |      $$ |  $$ |$$$$$/          $$$$$/      $$ |  $$ $$ $$ |$$$$$$$$ |  $$ |   $$$$$$  |
$$ / \$$ |$$ \__$$ |$$ |  $$ |$$ |  $$ |   $$ |  $$ |  $$ |/  \__$$ |      $$ |__$$ |$$ |_____       $$ |       _$$ |_ $$ |$$$$ |$$ |  $$ | _$$ |_ /  \__$$ |
$$ $$ $$< $$    $$/ $$ |  $$ |$$ |  $$ |   $$ |  $$ |  $$ |$$    $$/       $$    $$/ $$       |      $$ |      / $$   |$$ | $$$ |$$ |  $$ |/ $$   |$$    $$/
 $$$$$$  | $$$$$$/  $$/   $$/ $$/   $$/    $$/   $$/   $$/  $$$$$$/        $$$$$$$/  $$$$$$$$/       $$/       $$$$$$/ $$/   $$/ $$/   $$/ $$$$$$/  $$$$$$/
     $$$/




)EOF");
textcolor(WHITE);
    for (int i = 0; i < NUM_CLUBES / 4; i++)
        {
            //atribui o clube que est� em i para a variavel clubeA
        Clube clubeA = clubes[i];
    //O clube na posi��o complementar ao i � atribu�do � vari�vel clubeB. Isso � feito subtraindo 1 do n�mero total de clubes (NUM_CLUBES) e subtraindo i novamente para obter a posi��o correspondente na segunda metade do array.
        Clube clubeB = clubes[NUM_CLUBES / 2 - 1 - i];
// chama a fun��o realizarJogo passa pelas variaveis e realiza o jogo entreo os 2: 1 para clubeA, 2 para clubeB
        int vencedor = realizarJogo(clubeA, clubeB);
//Com base no vencedor retornado pela fun��o realizarJogo(), o clube vencedor � atribu�do � posi��o i do array clubes. Se o vencedor for 1, clubeA � atribu�do; caso contr�rio, clubeB
        clubes[i] = vencedor == 1 ? clubeA : clubeB;
        textcolor(YELLOW);
        printf("Vencedor da partida: %s\n\n", clubes[i].nome);
        textcolor(WHITE);
    }
system("cls");
    // Fase de Semifinal
    textcolor(BLUE);
    printf(R"EOF(

                                                         ______   ________  __       __  ______  ________  ______  __    __   ______   ______   ______
                                                        /      \ /        |/  \     /  |/      |/        |/      |/  \  /  | /      \ /      | /      \
                                                       /$$$$$$  |$$$$$$$$/ $$  \   /$$ |$$$$$$/ $$$$$$$$/ $$$$$$/ $$  \ $$ |/$$$$$$  |$$$$$$/ /$$$$$$  |
                                                       $$ \__$$/ $$ |__    $$$  \ /$$$ |  $$ |  $$ |__      $$ |  $$$  \$$ |$$ |__$$ |  $$ |  $$ \__$$/
                                                       $$      \ $$    |   $$$$  /$$$$ |  $$ |  $$    |     $$ |  $$$$  $$ |$$    $$ |  $$ |  $$      \
                                                        $$$$$$  |$$$$$/    $$ $$ $$/$$ |  $$ |  $$$$$/      $$ |  $$ $$ $$ |$$$$$$$$ |  $$ |   $$$$$$  |
                                                       /  \__$$ |$$ |_____ $$ |$$$/ $$ | _$$ |_ $$ |       _$$ |_ $$ |$$$$ |$$ |  $$ | _$$ |_ /  \__$$ |
                                                       $$    $$/ $$       |$$ | $/  $$ |/ $$   |$$ |      / $$   |$$ | $$$ |$$ |  $$ |/ $$   |$$    $$/
                                                        $$$$$$/  $$$$$$$$/ $$/      $$/ $$$$$$/ $$/       $$$$$$/ $$/   $$/ $$/   $$/ $$$$$$/  $$$$$$/





)EOF");
textcolor(WHITE);
    for (int i = 0; i < NUM_CLUBES / 8; i++)
        {
            //atribui o clube que est� em i para a variavel clubeA
        Clube clubeA = clubes[i];
        //O clube na posi��o complementar ao i � atribu�do � vari�vel clubeB. Isso � feito subtraindo 1 do n�mero total de clubes (NUM_CLUBES) e subtraindo i novamente para obter a posi��o correspondente na segunda metade do array.
        Clube clubeB = clubes[NUM_CLUBES / 4 - 1 - i];
// chama a fun��o realizarJogo passa pelas variaveis e realiza o jogo entreo os 2: 1 para clubeA, 2 para clubeB
        int vencedor = realizarJogo(clubeA, clubeB);
//Com base no vencedor retornado pela fun��o realizarJogo(), o clube vencedor � atribu�do � posi��o i do array clubes. Se o vencedor for 1, clubeA � atribu�do; caso contr�rio, clubeB
        clubes[i] = vencedor == 1 ? clubeA : clubeB;
        textcolor(YELLOW);
        printf("Vencedor da partida: %s\n\n", clubes[i].nome);
        textcolor(WHITE);
    }
system("cls");
    // Fase Final
    textcolor(BLUE);
    printf(R"EOF(


                                                           ________  ______  __    __   ______   __
                                                          /        |/      |/  \  /  | /      \ /  |
                                                          $$$$$$$$/ $$$$$$/ $$  \ $$ |/$$$$$$  |$$ |
                                                          $$ |__      $$ |  $$$  \$$ |$$ |__$$ |$$ |
                                                          $$    |     $$ |  $$$$  $$ |$$    $$ |$$ |
                                                          $$$$$/      $$ |  $$ $$ $$ |$$$$$$$$ |$$ |
                                                          $$ |       _$$ |_ $$ |$$$$ |$$ |  $$ |$$ |_____
                                                          $$ |      / $$   |$$ | $$$ |$$ |  $$ |$$       |
                                                          $$/       $$$$$$/ $$/   $$/ $$/   $$/ $$$$$$$$/





)EOF");
textcolor(WHITE);
// o primeiro clube do array (0) clubes � atribu�do � vari�vel clubeA
    Clube clubeA = clubes[0];
    //calcula a posi��o do clube na oitava parte do array e atribui a clubeB
    Clube clubeB = clubes[NUM_CLUBES / 8 - 1];
//realiza o jogo
    int vencedor = realizarJogo(clubeA, clubeB);
    int arm;
//verifica se o valor de vencedor � igual a 1. Se for verdadeiro, o clube clubeA � atribu�do a campeao; caso contr�rio, o clube clubeB � atribu�do.
    Clube campeao = vencedor == 1 ? clubeA : clubeB;
    textcolor(YELLOW);
    printf("Vencedor da partida: %s\n\n", clubes[i].nome);
    textcolor(WHITE);
system("cls");
    printf("\n%s � O CAMPE�O DA EUROPA!!!\n", campeao.nome);
    textcolor(BLUE);
    printf(R"EOF(


                                           __      __  ______   __    __         ______   _______   ________               ______
                                          /  \    /  |/      \ /  |  /  |       /      \ /       \ /        |             /      \
                                          $$  \  /$$//$$$$$$  |$$ |  $$ |      /$$$$$$  |$$$$$$$  |$$$$$$$$/             /$$$$$$  |
                                           $$  \/$$/ $$ |  $$ |$$ |  $$ |      $$ |__$$ |$$ |__$$ |$$ |__                $$ |__$$ |
                                            $$  $$/  $$ |  $$ |$$ |  $$ |      $$    $$ |$$    $$< $$    |               $$    $$ |
                                             $$$$/   $$ |  $$ |$$ |  $$ |      $$$$$$$$ |$$$$$$$  |$$$$$/                $$$$$$$$ |
                                              $$ |   $$ \__$$ |$$ \__$$ |      $$ |  $$ |$$ |  $$ |$$ |_____             $$ |  $$ |
                                              $$ |   $$    $$/ $$    $$/       $$ |  $$ |$$ |  $$ |$$       |            $$ |  $$ |
                                              $$/     $$$$$$/   $$$$$$/        $$/   $$/ $$/   $$/ $$$$$$$$/             $$/   $$/



  ______   __    __   ______   __       __  _______   ______   ______   __    __         ______   ________        ________  __    __  _______    ______   _______   ________  __  __  __
 /      \ /  |  /  | /      \ /  \     /  |/       \ /      | /      \ /  \  /  |       /      \ /        |      /        |/  |  /  |/       \  /      \ /       \ /        |/  |/  |/  |
/$$$$$$  |$$ |  $$ |/$$$$$$  |$$  \   /$$ |$$$$$$$  |$$$$$$/ /$$$$$$  |$$  \ $$ |      /$$$$$$  |$$$$$$$$/       $$$$$$$$/ $$ |  $$ |$$$$$$$  |/$$$$$$  |$$$$$$$  |$$$$$$$$/ $$ |$$ |$$ |
$$ |  $$/ $$ |__$$ |$$ |__$$ |$$$  \ /$$$ |$$ |__$$ |  $$ |  $$ |  $$ |$$$  \$$ |      $$ |  $$ |$$ |__          $$ |__    $$ |  $$ |$$ |__$$ |$$ |  $$ |$$ |__$$ |$$ |__    $$ |$$ |$$ |
$$ |      $$    $$ |$$    $$ |$$$$  /$$$$ |$$    $$/   $$ |  $$ |  $$ |$$$$  $$ |      $$ |  $$ |$$    |         $$    |   $$ |  $$ |$$    $$< $$ |  $$ |$$    $$/ $$    |   $$ |$$ |$$ |
$$ |   __ $$$$$$$$ |$$$$$$$$ |$$ $$ $$/$$ |$$$$$$$/    $$ |  $$ |  $$ |$$ $$ $$ |      $$ |  $$ |$$$$$/          $$$$$/    $$ |  $$ |$$$$$$$  |$$ |  $$ |$$$$$$$/  $$$$$/    $$/ $$/ $$/
$$ \__/  |$$ |  $$ |$$ |  $$ |$$ |$$$/ $$ |$$ |       _$$ |_ $$ \__$$ |$$ |$$$$ |      $$ \__$$ |$$ |            $$ |_____ $$ \__$$ |$$ |  $$ |$$ \__$$ |$$ |      $$ |_____  __  __  __
$$    $$/ $$ |  $$ |$$ |  $$ |$$ | $/  $$ |$$ |      / $$   |$$    $$/ $$ | $$$ |      $$    $$/ $$ |            $$       |$$    $$/ $$ |  $$ |$$    $$/ $$ |      $$       |/  |/  |/  |
 $$$$$$/  $$/   $$/ $$/   $$/ $$/      $$/ $$/       $$$$$$/  $$$$$$/  $$/   $$/        $$$$$$/  $$/             $$$$$$$$/  $$$$$$/  $$/   $$/  $$$$$$/  $$/       $$$$$$$$/ $$/ $$/ $$/




)EOF");
textcolor(WHITE);

    printf("\n");
    printf("Pressione qualquer tecla para guardar\n");
    buss = getch();
    system("cls");
     textcolor(RED);
    printf(R"EOF(

 __    __   ______          ______   _______    ______    ______   ________        ________  ______          ______   ________  ______   _______    ______    ______   ________
/  \  /  | /      \        /      \ /       \  /      \  /      \ /        |      /        |/      \        /      \ /        |/      \ /       \  /      \  /      \ /        |
$$  \ $$ |/$$$$$$  |      /$$$$$$  |$$$$$$$  |/$$$$$$  |/$$$$$$  |$$$$$$$$/       $$$$$$$$//$$$$$$  |      /$$$$$$  |$$$$$$$$//$$$$$$  |$$$$$$$  |/$$$$$$  |/$$$$$$  |$$$$$$$$/
$$$  \$$ |$$ |  $$ |      $$ \__$$/ $$ |__$$ |$$ |__$$ |$$ |  $$/ $$ |__             $$ |  $$ |  $$ |      $$ \__$$/    $$ |  $$ |  $$ |$$ |__$$ |$$ |__$$ |$$ | _$$/ $$ |__
$$$$  $$ |$$ |  $$ |      $$      \ $$    $$/ $$    $$ |$$ |      $$    |            $$ |  $$ |  $$ |      $$      \    $$ |  $$ |  $$ |$$    $$< $$    $$ |$$ |/    |$$    |
$$ $$ $$ |$$ |  $$ |       $$$$$$  |$$$$$$$/  $$$$$$$$ |$$ |   __ $$$$$/             $$ |  $$ |  $$ |       $$$$$$  |   $$ |  $$ |  $$ |$$$$$$$  |$$$$$$$$ |$$ |$$$$ |$$$$$/
$$ |$$$$ |$$ \__$$ |      /  \__$$ |$$ |      $$ |  $$ |$$ \__/  |$$ |_____          $$ |  $$ \__$$ |      /  \__$$ |   $$ |  $$ \__$$ |$$ |  $$ |$$ |  $$ |$$ \__$$ |$$ |_____
$$ | $$$ |$$    $$/       $$    $$/ $$ |      $$ |  $$ |$$    $$/ $$       |         $$ |  $$    $$/       $$    $$/    $$ |  $$    $$/ $$ |  $$ |$$ |  $$ |$$    $$/ $$       |
$$/   $$/  $$$$$$/         $$$$$$/  $$/       $$/   $$/  $$$$$$/  $$$$$$$$/          $$/    $$$$$$/         $$$$$$/     $$/    $$$$$$/  $$/   $$/ $$/   $$/  $$$$$$/  $$$$$$$$/




)EOF");
textcolor(WHITE);
printf("\n");
sleep(3);
system("cls");
textcolor(BLUE);
    printf(R"EOF(
                                                                               _____ _    _          __  __ _____ _____ ____  _   _  _____
                                                                              / ____| |  | |   /\   |  \/  |  __ \_   _/ __ \| \ | |/ ____|
                                                                             | |    | |__| |  /  \  | \  / | |__) || || |  | |  \| | (___
                                                                             | |    |  __  | / /\ \ | |\/| |  ___/ | || |  | | . ` |\___ \
                                                                             | |____| |  | |/ ____ \| |  | | |    _| || |__| | |\  |____) |
                                                                              \_____|_|  |_/_/    \_\_|  |_|_|   |_____\____/|_| \_|_____/

                                                           _____   ____          _____    _______ ____    _______ _    _ ______   ______ _____ _   _          _
                                                          |  __ \ / __ \   /\   |  __ \  |__   __/ __ \  |__   __| |  | |  ____| |  ____|_   _| \ | |   /\   | |
                                                          | |__) | |  | | /  \  | |  | |    | | | |  | |    | |  | |__| | |__    | |__    | | |  \| |  /  \  | |
                                                          |  _  /| |  | |/ /\ \ | |  | |    | | | |  | |    | |  |  __  |  __|   |  __|   | | | . ` | / /\ \ | |
                                                          | | \ \| |__| / ____ \| |__| |    | | | |__| |    | |  | |  | | |____  | |     _| |_| |\  |/ ____ \| |____
                                                          |_|  \_\\____/_/    \_\_____/     |_|  \____/     |_|  |_|  |_|______| |_|    |_____|_| \_/_/    \_\______|


)EOF");
textcolor(WHITE);




                        break;
                    case '4':
                        textcolor(GREEN);
                        char str[] = "Executando: Hist�rico";
                        strupr(str);

                        printf("%s\n", str);

                        noesp(arm);
                        break;
                    case '0':
                        textcolor(YELLOW);
                        char strr[] = "Voltando ao menu de login...";
                        strupr(strr);

                        printf("%s\n", strr);
                        break;
                    default:
                        textcolor(RED);
                        char strrr[] = "Op��o inv�lida, tente novamente.";
                        strupr(strrr);

                        printf("%s\n", strrr);
                        textcolor(BLUE);
    printf(R"EOF(
                                                                               _____ _    _          __  __ _____ _____ ____  _   _  _____
                                                                              / ____| |  | |   /\   |  \/  |  __ \_   _/ __ \| \ | |/ ____|
                                                                             | |    | |__| |  /  \  | \  / | |__) || || |  | |  \| | (___
                                                                             | |    |  __  | / /\ \ | |\/| |  ___/ | || |  | | . ` |\___ \
                                                                             | |____| |  | |/ ____ \| |  | | |    _| || |__| | |\  |____) |
                                                                              \_____|_|  |_/_/    \_\_|  |_|_|   |_____\____/|_| \_|_____/

                                                           _____   ____          _____    _______ ____    _______ _    _ ______   ______ _____ _   _          _
                                                          |  __ \ / __ \   /\   |  __ \  |__   __/ __ \  |__   __| |  | |  ____| |  ____|_   _| \ | |   /\   | |
                                                          | |__) | |  | | /  \  | |  | |    | | | |  | |    | |  | |__| | |__    | |__    | | |  \| |  /  \  | |
                                                          |  _  /| |  | |/ /\ \ | |  | |    | | | |  | |    | |  |  __  |  __|   |  __|   | | | . ` | / /\ \ | |
                                                          | | \ \| |__| / ____ \| |__| |    | | | |__| |    | |  | |  | | |____  | |     _| |_| |\  |/ ____ \| |____
                                                          |_|  \_\\____/_/    \_\_____/     |_|  \____/     |_|  |_|  |_|______| |_|    |_____|_| \_/_/    \_\______|


)EOF");
textcolor(WHITE);
                        break;
                }

                printf("\n");
                //sefor igual a 0 ir� voltar � pagina de login
            } while (menuChoice != '0');

            return;
        }
    }
textcolor(RED);
    char strrrr[] = "Erro no Login, Username ou passeword errados.";
                        strupr(strrrr);

                        printf("%s\n", strrrr);
}

int main() {
    //fullscreen
    keybd_event(VK_MENU  , 0x36, 0, 0);
    keybd_event(VK_RETURN, 0x1C, 0, 0);
    keybd_event(VK_RETURN, 0x1C, KEYEVENTF_KEYUP, 0);
    keybd_event(VK_MENU  , 0x38, KEYEVENTF_KEYUP, 0);





    char choice;
    int info;
    setlocale(LC_ALL,"Portuguese");

    // Carregar os usu�rios do arquivo
    loadUsers();

    // Exibir a p�gina inicial
    textcolor(BLUE);
    printf(R"EOF(
                                                                               _____ _    _          __  __ _____ _____ ____  _   _  _____
                                                                              / ____| |  | |   /\   |  \/  |  __ \_   _/ __ \| \ | |/ ____|
                                                                             | |    | |__| |  /  \  | \  / | |__) || || |  | |  \| | (___
                                                                             | |    |  __  | / /\ \ | |\/| |  ___/ | || |  | | . ` |\___ \
                                                                             | |____| |  | |/ ____ \| |  | | |    _| || |__| | |\  |____) |
                                                                              \_____|_|  |_/_/    \_\_|  |_|_|   |_____\____/|_| \_|_____/

                                                           _____   ____          _____    _______ ____    _______ _    _ ______   ______ _____ _   _          _
                                                          |  __ \ / __ \   /\   |  __ \  |__   __/ __ \  |__   __| |  | |  ____| |  ____|_   _| \ | |   /\   | |
                                                          | |__) | |  | | /  \  | |  | |    | | | |  | |    | |  | |__| | |__    | |__    | | |  \| |  /  \  | |
                                                          |  _  /| |  | |/ /\ \ | |  | |    | | | |  | |    | |  |  __  |  __|   |  __|   | | | . ` | / /\ \ | |
                                                          | | \ \| |__| / ____ \| |__| |    | | | |__| |    | |  | |  | | |____  | |     _| |_| |\  |/ ____ \| |____
                                                          |_|  \_\\____/_/    \_\_____/     |_|  \____/     |_|  |_|  |_|______| |_|    |_____|_| \_/_/    \_\______|


)EOF");
textcolor(WHITE);

    printf("Pressione qualquer tecla para iniciar o programa ou 2 para sair.\n");
    choice = getch();
    system("cls");


    if (choice == '2')
        {
            textcolor(YELLOW);

        char str1[] = "Saindo...";
                        strupr(str1);

                        printf("%s\n", str1);
                        textcolor(WHITE);
                return 0;
    }

    do {
            textcolor(BLUE);
    printf(R"EOF(

                                                                               _____ _    _          __  __ _____ _____ ____  _   _  _____
                                                                              / ____| |  | |   /\   |  \/  |  __ \_   _/ __ \| \ | |/ ____|
                                                                             | |    | |__| |  /  \  | \  / | |__) || || |  | |  \| | (___
                                                                             | |    |  __  | / /\ \ | |\/| |  ___/ | || |  | | . ` |\___ \
                                                                             | |____| |  | |/ ____ \| |  | | |    _| || |__| | |\  |____) |
                                                                              \_____|_|  |_/_/    \_\_|  |_|_|   |_____\____/|_| \_|_____/

                                                           _____   ____          _____    _______ ____    _______ _    _ ______   ______ _____ _   _          _
                                                          |  __ \ / __ \   /\   |  __ \  |__   __/ __ \  |__   __| |  | |  ____| |  ____|_   _| \ | |   /\   | |
                                                          | |__) | |  | | /  \  | |  | |    | | | |  | |    | |  | |__| | |__    | |__    | | |  \| |  /  \  | |
                                                          |  _  /| |  | |/ /\ \ | |  | |    | | | |  | |    | |  |  __  |  __|   |  __|   | | | . ` | / /\ \ | |
                                                          | | \ \| |__| / ____ \| |__| |    | | | |__| |    | |  | |  | | |____  | |     _| |_| |\  |/ ____ \| |____
                                                          |_|  \_\\____/_/    \_\_____/     |_|  \____/     |_|  |_|  |_|______| |_|    |_____|_| \_/_/    \_\______|


)EOF");
textcolor(WHITE);
        printf("\n==== Menu ====\n");
        printf("1. Registrar novo usu�rio\n");
        printf("2. Login\n");
        printf("0. Sair\n");
        printf("Escolha uma op��o: ");
        scanf(" %c", &choice);
        fflush(stdin);

        switch (choice)
        {
            case '1':
                system("cls");
                registerUser();
                break;
            case '2':
                system("cls");
                login();
                break;
            case '0':
                system("cls");
                textcolor(YELLOW);
                printf("Saindo...\n");
                textcolor(WHITE);
                break;
            default:
                system("cls");
                textcolor(RED);
                printf("Op��o inv�lida. Tente novamente.\n");
                break;
        }

        printf("\n");
    } while (choice != '0');

    return 0;
}
