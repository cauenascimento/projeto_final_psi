#ifndef INFO_CLUBS_H_INCLUDED
#define INFO_CLUBS_H_INCLUDED
#include <locale.h>

void infoclub(int info)

{
    setlocale(LC_ALL,"Portuguese");
    switch(info)
    {
        case 1:
            textcolor(15);
                printf(R"EOF(



8888888b.  8888888888        d8888 888           888b     d888        d8888 8888888b.  8888888b.  8888888 8888888b.
888   Y88b 888              d88888 888           8888b   d8888       d88888 888  "Y88b 888   Y88b   888   888  "Y88b
888    888 888             d88P888 888           88888b.d88888      d88P888 888    888 888    888   888   888    888
888   d88P 8888888        d88P 888 888           888Y88888P888     d88P 888 888    888 888   d88P   888   888    888
8888888P"  888           d88P  888 888           888 Y888P 888    d88P  888 888    888 8888888P"    888   888    888
888 T88b   888          d88P   888 888           888  Y8P  888   d88P   888 888    888 888 T88b     888   888    888
888  T88b  888         d8888888888 888           888   "   888  d8888888888 888  .d88P 888  T88b    888   888  .d88P
888   T88b 8888888888 d88P     888 88888888      888       888 d88P     888 8888888P"  888   T88b 8888888 8888888P"




)EOF");
textcolor(WHITE);
            printf("Real Madrid:\n");
            printf("Fundacao: 6 de março de 1902\n");
            printf("Estadio: Santiago Bernabéu\n");
            printf("Sobre:\n");
            printf("O Real Madrid é um famoso clube de futebol espanhol sediado em Madrid. Fundado em 1902, é um dos clubes mais bem-sucedidos da história, com um extenso número de títulos nacionais e internacionais.\n Conhecido por sua camisa branca icônica, o Real Madrid conquistou a Liga dos Campeões da UEFA 14 vezes e é reconhecido por ter contado com grandes jogadores, como Cristiano Ronaldo e Di Stéfano, ao longo de sua história.\n É também um dos clubes mais valiosos e populares do mundo.\n");
            printf("Edições Ganhas:\n");
            printf("1955-56  1956-57  1957-58  1958-59  1959-60  1965-66  1997-98\n1999-00  2001-02  2013-14  2015-16  2016-17  2017-18  2021-22");
            break;
        case 2:
            textcolor(RED);
                printf(R"EOF(



       d8888  .d8888b.       888b     d888 8888888 888             d8888 888b    888
      d88888 d88P  Y88b      8888b   d8888   888   888            d88888 8888b   888
     d88P888 888    888      88888b.d88888   888   888           d88P888 88888b  888
    d88P 888 888             888Y88888P888   888   888          d88P 888 888Y88b 888
   d88P  888 888             888 Y888P 888   888   888         d88P  888 888 Y88b888
  d88P   888 888    888      888  Y8P  888   888   888        d88P   888 888  Y88888
 d8888888888 Y88b  d88P      888   "   888   888   888       d8888888888 888   Y8888
d88P     888  "Y8888P"       888       888 8888888 88888888 d88P     888 888    Y888





)EOF");
textcolor(WHITE);
            printf("AC Milan\n");
            printf("Fundacao: 16 de dezembro de 1899\n");
            printf("Estadio: San Siro\n");
            printf("Sobre:\n");
            printf("O AC Milan é um renomado clube de futebol italiano com sede em Milão.\n Fundado em 1899, é um dos clubes mais tradicionais do país. O AC Milan é conhecido por suas cores vermelho e preto e tem uma história rica em conquistas, incluindo títulos nacionais e internacionais.\n O clube já venceu a Liga dos Campeões da UEFA 7 vezes e possui uma base de fãs apaixonada em todo o mundo.\n Ao longo dos anos, o AC Milan teve jogadores lendários, como Paolo Maldini e Marco van Basten, contribuindo para sua reputação como um dos principais clubes do futebol italiano e europeu.\n");
            printf("Edições Ganhas:\n");
             printf("1962–63  1968–69  1988–89  1989–90\n1993–94  2002–03  2006–07");
            break;
        case 3:
            textcolor(LIGHTRED);
                printf(R"EOF(



888888b.         d8888 Y88b   d88P 8888888888 8888888b.  888b    888      888b     d888 888     888 888b    888 8888888 .d8888b.  888    888
888  "88b       d88888  Y88b d88P  888        888   Y88b 8888b   888      8888b   d8888 888     888 8888b   888   888  d88P  Y88b 888    888
888  .88P      d88P888   Y88o88P   888        888    888 88888b  888      88888b.d88888 888     888 88888b  888   888  888    888 888    888
8888888K.     d88P 888    Y888P    8888888    888   d88P 888Y88b 888      888Y88888P888 888     888 888Y88b 888   888  888        8888888888
888  "Y88b   d88P  888     888     888        8888888P"  888 Y88b888      888 Y888P 888 888     888 888 Y88b888   888  888        888    888
888    888  d88P   888     888     888        888 T88b   888  Y88888      888  Y8P  888 888     888 888  Y88888   888  888    888 888    888
888   d88P d8888888888     888     888        888  T88b  888   Y8888      888   "   888 Y88b. .d88P 888   Y8888   888  Y88b  d88P 888    888
8888888P" d88P     888     888     8888888888 888   T88b 888    Y888      888       888  "Y88888P"  888    Y888 8888888 "Y8888P"  888    888





)EOF");
textcolor(WHITE);
            printf("Bayern Munich\n");
            printf("Fundacao: 27 de fevereiro de 1900\n");
            printf("Estadio: Allianz Arena\n");
            printf("Sobre:\n");
            printf("O Bayern de Munique (Bayern Munich) é um famoso clube de futebol alemão baseado em Munique.\n Fundado em 1900, é um dos clubes mais bem-sucedidos da Alemanha e do mundo.\n O Bayern de Munique é conhecido por suas cores vermelho e branco, e conquistou inúmeros títulos nacionais e internacionais ao longo de sua história.\n O clube é reconhecido por ter contado com jogadores lendários, como Franz Beckenbauer e Gerd Müller.\n Além disso, o Bayern de Munique é conhecido por seu estádio icônico, a Allianz Arena, e por ser um dos clubes mais valiosos e bem administrados do futebol mundial.\n");
            printf("Edições Ganhas:\n");
            printf("1973-1974  1974-1975  1975-1976 \n 2000-2001  2012-2013  2019-2020");
            break;

            case 4:
                textcolor(RED);
                printf(R"EOF(



888      8888888 888     888 8888888888 8888888b.  8888888b.   .d88888b.   .d88888b.  888
888        888   888     888 888        888   Y88b 888   Y88b d88P" "Y88b d88P" "Y88b 888
888        888   888     888 888        888    888 888    888 888     888 888     888 888
888        888   Y88b   d88P 8888888    888   d88P 888   d88P 888     888 888     888 888
888        888    Y88b d88P  888        8888888P"  8888888P"  888     888 888     888 888
888        888     Y88o88P   888        888 T88b   888        888     888 888     888 888
888        888      Y888P    888        888  T88b  888        Y88b. .d88P Y88b. .d88P 888
88888888 8888888     Y8P     8888888888 888   T88b 888         "Y88888P"   "Y88888P"  88888888





)EOF");
textcolor(WHITE);
            printf("Liverpool\n");
            printf("Fundacao:  3 de junho de 1892\n");
            printf("Estadio: Anfield\n");
            printf("Sobre:\n");
            printf("O Liverpool é um proeminente clube de futebol inglês com sede na cidade de Liverpool.\n Fundado em 1892, o clube é conhecido por suas cores vermelho e branco.\n O Liverpool possui uma história rica em conquistas, com muitos títulos nacionais e internacionais.\n O clube ganhou a Liga dos Campeões da UEFA em 6 ocasiões e é reconhecido por sua atmosfera apaixonada no estádio Anfield.\n O Liverpool tem uma base de fãs leal e é famoso por seus momentos memoráveis ​​e jogadores lendários, como Steven Gerrard e Kenny Dalglish.\n É um dos clubes mais icônicos do futebol inglês e europeu.\n");
            printf("Edições Ganhas:\n");
            printf("1976-1977  1977-1978  1980-1981 \n 1983-1984  2004-2005  2018-2019");
            break;


            case 5:
                textcolor(LIGHTMAGENTA);
                printf(R"EOF(



888888b.         d8888 8888888b.   .d8888b.  8888888888 888      .d88888b.  888b    888        d8888
888  "88b       d88888 888   Y88b d88P  Y88b 888        888     d88P" "Y88b 8888b   888       d88888
888  .88P      d88P888 888    888 888    888 888        888     888     888 88888b  888      d88P888
8888888K.     d88P 888 888   d88P 888        8888888    888     888     888 888Y88b 888     d88P 888
888  "Y88b   d88P  888 8888888P"  888        888        888     888     888 888 Y88b888    d88P  888
888    888  d88P   888 888 T88b   888    888 888        888     888     888 888  Y88888   d88P   888
888   d88P d8888888888 888  T88b  Y88b  d88P 888        888     Y88b. .d88P 888   Y8888  d8888888888
8888888P" d88P     888 888   T88b  "Y8888P"  8888888888 88888888 "Y88888P"  888    Y888 d88P     888





)EOF");
textcolor(WHITE);
            printf("Barcelona\n");
            printf("Fundacao: 29 de novembro de 1899\n");
            printf("Estadio: Spotify Camp Nou\n");
            printf("Sobre:\n");
            printf("O FC Barcelona, também conhecido como Barça, é um renomado clube de futebol espanhol sediado em Barcelona.\h Fundado em 1899, o clube é reconhecido por suas cores azul e grená.\h O Barcelona é famoso por seu estilo de jogo característico, baseado na posse de bola e na habilidade técnica de seus jogadores.\h O clube conquistou inúmeros títulos nacionais e internacionais, incluindo a Liga dos Campeões da UEFA.\h O Barcelona é associado a grandes jogadores, como Lionel Messi, Xavi Hernández e Andrés Iniesta, e é considerado um dos clubes mais prestigiosos e bem-sucedidos do futebol mundial.\n");
            printf("Edições Ganhas:\n");
            printf("1991-1992  2005-2006  2008-2009 \n 2010-2011  2014-2015");
            break;

            case 6:
                textcolor(15);
                printf(R"EOF(



       d8888 888888        d8888 Y88b   d88P
      d88888   "88b       d88888  Y88b d88P
     d88P888    888      d88P888   Y88o88P
    d88P 888    888     d88P 888    Y888P
   d88P  888    888    d88P  888    d888b
  d88P   888    888   d88P   888   d88888b
 d8888888888    88P  d8888888888  d88P Y88b
d88P     888    888 d88P     888 d88P   Y88b
              .d88P
            .d88P"
           888P"


)EOF");
textcolor(WHITE);
            printf("Ajax\n");
            printf("Fundacao: 18 de março de 1900\n");
            printf("Estadio: Johan Cruijff Arena\n");
            printf("Sobre:\n");
            printf("O Ajax é um conhecido clube de futebol holandês com sede em Amsterdã.\n Fundado em 1900, o Ajax é reconhecido por suas cores vermelho e branco.\n O clube possui uma história de sucesso, tendo conquistado vários títulos nacionais e internacionais, incluindo a Liga dos Campeões da UEFA.\n O Ajax é conhecido por seu estilo de jogo ofensivo e por desenvolver jovens talentos em sua famosa academia de futebol.\n Ao longo dos anos, o clube produziu jogadores lendários, como Johan Cruyff e Marco van Basten, e continua sendo um dos clubes mais proeminentes da Holanda e da Europa.\n");
            printf("Edições Ganhas:\n");
            printf("1970–71  1971–72 \n 1972–73  1994–95");
            break;

            case 7:
                textcolor(RED);
                printf(R"EOF(



888b     d888        d8888 888b    888  .d8888b.  888    888 8888888888 .d8888b. 88888888888 8888888888 8888888b.       888     888 888b    888 8888888 88888888888 8888888888 8888888b.
8888b   d8888       d88888 8888b   888 d88P  Y88b 888    888 888       d88P  Y88b    888     888        888   Y88b      888     888 8888b   888   888       888     888        888  "Y88b
88888b.d88888      d88P888 88888b  888 888    888 888    888 888       Y88b.         888     888        888    888      888     888 88888b  888   888       888     888        888    888
888Y88888P888     d88P 888 888Y88b 888 888        8888888888 8888888    "Y888b.      888     8888888    888   d88P      888     888 888Y88b 888   888       888     8888888    888    888
888 Y888P 888    d88P  888 888 Y88b888 888        888    888 888           "Y88b.    888     888        8888888P"       888     888 888 Y88b888   888       888     888        888    888
888  Y8P  888   d88P   888 888  Y88888 888    888 888    888 888             "888    888     888        888 T88b        888     888 888  Y88888   888       888     888        888    888
888   "   888  d8888888888 888   Y8888 Y88b  d88P 888    888 888       Y88b  d88P    888     888        888  T88b       Y88b. .d88P 888   Y8888   888       888     888        888  .d88P
888       888 d88P     888 888    Y888  "Y8888P"  888    888 8888888888 "Y8888P"     888     8888888888 888   T88b       "Y88888P"  888    Y888 8888888     888     8888888888 8888888P"





)EOF");
textcolor(WHITE);
            printf("Manchester United\n");
            printf("Fundacao: 1878\n");
            printf("Estadio: Old Trashford\n");
            printf("Sobre:\n");
            printf("O Manchester United, também conhecido como Man United, é um renomado clube de futebol inglês sediado em Manchester.\n Fundado em 1878, o clube é famoso por suas cores vermelho e branco.\n O Manchester United é uma das equipes mais bem-sucedidas da Inglaterra, com um histórico de conquistas nacionais e internacionais.\n O clube ganhou a Liga dos Campeões da UEFA 3 vezes e teve grandes jogadores, como George Best, Eric Cantona e Cristiano Ronaldo, em suas fileiras ao longo dos anos.\n O Manchester United possui uma base de fãs global e é considerado um dos clubes mais populares e influentes do futebol mundial.\n");
            printf("Edições Ganhas:\n");
            printf("1967-1968  1998-1999  2007-2008");
            break;

            case 8:
                textcolor(BLUE);
                printf(R"EOF(



8888888 888b    888 88888888888 8888888888 8888888b.       8888888b.  8888888888      888b     d888 8888888 888             d8888  .d88888b.
  888   8888b   888     888     888        888   Y88b      888  "Y88b 888             8888b   d8888   888   888            d88888 d88P" "Y88b
  888   88888b  888     888     888        888    888      888    888 888             88888b.d88888   888   888           d88P888 888     888
  888   888Y88b 888     888     8888888    888   d88P      888    888 8888888         888Y88888P888   888   888          d88P 888 888     888
  888   888 Y88b888     888     888        8888888P"       888    888 888             888 Y888P 888   888   888         d88P  888 888     888
  888   888  Y88888     888     888        888 T88b        888    888 888             888  Y8P  888   888   888        d88P   888 888     888
  888   888   Y8888     888     888        888  T88b       888  .d88P 888             888   "   888   888   888       d8888888888 Y88b. .d88P
8888888 888    Y888     888     8888888888 888   T88b      8888888P"  8888888888      888       888 8888888 88888888 d88P     888  "Y88888P"





)EOF");
textcolor(WHITE);
            printf("Inter de Milão\n");
            printf("Fundacao: 9 de março de 1908\n");
            printf("Estadio: Giuseppe Meazza\n");
            printf("Sobre:\n");
            printf("O Inter de Milão, também conhecido como Internazionale ou Inter, é um proeminente clube de futebol italiano sediado em Milão.\n Fundado em 1908, o clube é conhecido por suas cores azul e preto.\n O Inter de Milão possui uma história rica em conquistas, com diversos títulos nacionais e internacionais.\n O clube ganhou a Liga dos Campeões da UEFA várias vezes e teve jogadores renomados, como Giuseppe Meazza, Ronaldo e Javier Zanetti, ao longo de sua trajetória.\n O Inter de Milão é reconhecido por sua rivalidade com o AC Milan e é considerado um dos clubes mais importantes do futebol italiano e europeu.\n");
            printf("Edições Ganhas:\n");
            printf("1990-1991  1993-1994  1997-1998");
            break;

            case 9:
                textcolor(LIGHTBLUE);
                printf(R"EOF(



 .d8888b.  888    888 8888888888 888      .d8888b.  8888888888        d8888
d88P  Y88b 888    888 888        888     d88P  Y88b 888              d88888
888    888 888    888 888        888     Y88b.      888             d88P888
888        8888888888 8888888    888      "Y888b.   8888888        d88P 888
888        888    888 888        888         "Y88b. 888           d88P  888
888    888 888    888 888        888           "888 888          d88P   888
Y88b  d88P 888    888 888        888     Y88b  d88P 888         d8888888888
 "Y8888P"  888    888 8888888888 88888888 "Y8888P"  8888888888 d88P     888





)EOF");
textcolor(WHITE);
            printf("Chelsea\n");
            printf("Fundacao: 10 de março de 1905\n");
            printf("Estadio: Stamford Bridge\n");
            printf("Sobre:\n");
            printf("O Chelsea é um proeminente clube de futebol inglês sediado em Londres.\n Fundado em 1905, o clube é conhecido por suas cores azul e branca.\n O Chelsea tem uma história de sucesso, com vários títulos nacionais e internacionais em seu nome.\n O clube ganhou a Liga dos Campeões da UEFA em algumas ocasiões e também foi bem-sucedido em competições domésticas, como a Premier League e a Copa da Inglaterra.\n O Chelsea possui uma base de fãs leal e é famoso por suas contratações de alto nível e por ter tido treinadores notáveis, como José Mourinho e Frank Lampard.\n É considerado um dos principais clubes do futebol inglês e europeu.\n");
            printf("Edições Ganhas:\n");
            printf("2011-2012  2020-2021");
            break;

            case 10:
                textcolor(RED);
                printf(R"EOF(



888b    888  .d88888b. 88888888888 88888888888 8888888 888b    888  .d8888b.  888    888        d8888 888b     d888      8888888888 .d88888b.  8888888b.  8888888888 .d8888b. 88888888888
8888b   888 d88P" "Y88b    888         888       888   8888b   888 d88P  Y88b 888    888       d88888 8888b   d8888      888       d88P" "Y88b 888   Y88b 888       d88P  Y88b    888
88888b  888 888     888    888         888       888   88888b  888 888    888 888    888      d88P888 88888b.d88888      888       888     888 888    888 888       Y88b.         888
888Y88b 888 888     888    888         888       888   888Y88b 888 888        8888888888     d88P 888 888Y88888P888      8888888   888     888 888   d88P 8888888    "Y888b.      888
888 Y88b888 888     888    888         888       888   888 Y88b888 888  88888 888    888    d88P  888 888 Y888P 888      888       888     888 8888888P"  888           "Y88b.    888
888  Y88888 888     888    888         888       888   888  Y88888 888    888 888    888   d88P   888 888  Y8P  888      888       888     888 888 T88b   888             "888    888
888   Y8888 Y88b. .d88P    888         888       888   888   Y8888 Y88b  d88P 888    888  d8888888888 888   "   888      888       Y88b. .d88P 888  T88b  888       Y88b  d88P    888
888    Y888  "Y88888P"     888         888     8888888 888    Y888  "Y8888P88 888    888 d88P     888 888       888      888        "Y88888P"  888   T88b 8888888888 "Y8888P"     888





)EOF");
textcolor(WHITE);
            printf("Nottingham Forest\n");
            printf("Fundacao: 1865\n");
            printf("Estadio: City Ground\n");
            printf("Sobre:\n");
            printf("O Nottingham Forest é um clube de futebol inglês com sede na cidade de Nottingham.\n Fundado em 1865, o clube é conhecido por suas cores vermelho e branco.\n O Nottingham Forest teve seu período mais bem-sucedido nas décadas de 1970 e 1980, sob o comando do lendário treinador Brian Clough.\n Durante esse período, o clube conquistou a Liga dos Campeões da UEFA em duas ocasiões consecutivas, em 1978-1979 e 1979-1980. O Nottingham Forest tem uma base de fãs leal e é considerado um clube histórico do futebol inglês.\n Atualmente, o clube compete na Football League Championship, a segunda divisão do futebol inglês.\n");
            printf("Edições Ganhas:\n");
            printf("1978-1979  1979-1980");
            break;

            case 11:
                textcolor(LIGHTRED);
                printf(R"EOF(



888888b.   8888888888 888b    888 8888888888 8888888 .d8888b.        d8888
888  "88b  888        8888b   888 888          888  d88P  Y88b      d88888
888  .88P  888        88888b  888 888          888  888    888     d88P888
8888888K.  8888888    888Y88b 888 8888888      888  888           d88P 888
888  "Y88b 888        888 Y88b888 888          888  888          d88P  888
888    888 888        888  Y88888 888          888  888    888  d88P   888
888   d88P 888        888   Y8888 888          888  Y88b  d88P d8888888888
8888888P"  8888888888 888    Y888 888        8888888 "Y8888P" d88P     888





)EOF");
textcolor(WHITE);
            printf("Benfica\n");
            printf("Fundacao: 28 de fevereiro de 1904\n");
            printf("Estadio: Estádio da Luz\n");
            printf("Sobre:\n");
            printf("O Benfica é um renomado clube de futebol português com sede em Lisboa.\n Fundado em 1904, o clube é conhecido por suas cores vermelho e branco.\n O Benfica é um dos clubes mais bem-sucedidos de Portugal, tendo conquistado inúmeros títulos nacionais e internacionais ao longo de sua história.\n O clube ganhou a Liga dos Campeões da UEFA em duas ocasiões, em 1960-1961 e 1961-1962.\n O Benfica tem uma base de fãs apaixonada e é considerado um dos clubes mais populares e influentes de Portugal.\n");
            printf("Edições Ganhas:\n");
            printf("1960-1961  1961-1962");
            break;

            case 12:
                textcolor(LIGHTGRAY);
                printf(R"EOF(



  888888 888     888 888     888 8888888888 888b    888 88888888888 888     888  .d8888b.
    "88b 888     888 888     888 888        8888b   888     888     888     888 d88P  Y88b
     888 888     888 888     888 888        88888b  888     888     888     888 Y88b.
     888 888     888 Y88b   d88P 8888888    888Y88b 888     888     888     888  "Y888b.
     888 888     888  Y88b d88P  888        888 Y88b888     888     888     888     "Y88b.
     888 888     888   Y88o88P   888        888  Y88888     888     888     888       "888
     88P Y88b. .d88P    Y888P    888        888   Y8888     888     Y88b. .d88P Y88b  d88P
     888  "Y88888P"      Y8P     8888888888 888    Y888     888      "Y88888P"   "Y8888P"
   .d88P
 .d88P"
888P"


)EOF");
textcolor(WHITE);
            printf("Juventus\n");
            printf("Fundacao: 1 de novembro de 1897\n");
            printf("Estadio: Juventus Stadium\n");
            printf("Sobre:\n");
            printf("A Juventus é um prestigioso clube de futebol italiano sediado em Turim.\n Fundado em 1897, o clube é conhecido por suas cores preto e branco.\n A Juventus possui um histórico de sucesso, com vários títulos nacionais e internacionais em seu nome.\n O clube é famoso por ter contado com jogadores renomados, como Michel Platini, Alessandro Del Piero e atualmente com Cristiano Ronaldo.\n A Juventus é reconhecida por sua força defensiva e habilidade tática, sendo uma das equipes mais dominantes do futebol italiano.\n É considerada uma das principais equipes do futebol europeu e tem uma base de fãs apaixonada em todo o mundo.\n");
            printf("Edições Ganhas:\n");
            printf("1984-1985  1995-1996");
            break;

            case 13:
                textcolor(LIGHTBLUE);
                printf(R"EOF(



8888888b.   .d88888b.  8888888b. 88888888888 .d88888b.
888   Y88b d88P" "Y88b 888   Y88b    888    d88P" "Y88b
888    888 888     888 888    888    888    888     888
888   d88P 888     888 888   d88P    888    888     888
8888888P"  888     888 8888888P"     888    888     888
888        888     888 888 T88b      888    888     888
888        Y88b. .d88P 888  T88b     888    Y88b. .d88P
888         "Y88888P"  888   T88b    888     "Y88888P"





)EOF");
textcolor(WHITE);
            printf("Porto\n");
            printf("Fundacao: 28 de setembro de 1893\n");
            printf("Estadio:  Estádio do Dragão\n");
            printf("Sobre:\n");
            printf("O Porto é um renomado clube de futebol português com sede na cidade do Porto.\n Fundado em 1893, o clube é conhecido por suas cores azul e branco.\n O Porto possui uma rica história de sucesso, com vários títulos nacionais e internacionais em seu currículo.\n O clube ganhou a Liga dos Campeões da UEFA em duas ocasiões, em 1986-1987 e 2003-2004.\n O Porto é conhecido por sua mentalidade aguerrida e estilo de jogo ofensivo.\n É considerado um dos principais clubes de Portugal e tem uma base de fãs leal e apaixonada.\n");
            printf("Edições Ganhas:\n");
            printf("1986-1987  2003-2004");
            break;

            case 14:
                textcolor(YELLOW);
                printf(R"EOF(



888888b.  888     888 888888b.
888  "88b 888     888 888  "88b
888  .88P 888     888 888  .88P
8888888K. Y88b   d88P 8888888K.
888  "Y88b Y88b d88P  888  "Y88b
888    888  Y88o88P   888    888
888   d88P   Y888P    888   d88P
8888888P"     Y8P     8888888P"





)EOF");
textcolor(WHITE);
            printf("Borussia Dortmund\n");
            printf("Fundacao: 19 de dezembro de 1909\n");
            printf("Estadio:  Signal Iduna Park\n");
            printf("Sobre:\n");
            printf("O BVB, também conhecido como Borussia Dortmund, é um destacado clube de futebol alemão sediado em Dortmund.\n Fundado em 1909, o clube é conhecido por suas cores amarelo e preto.\n O BVB é famoso por sua intensidade e estilo de jogo ofensivo, além de ter uma base de fãs apaixonada.\n O clube conquistou vários títulos nacionais e internacionais, incluindo a Liga dos Campeões da UEFA em 1996-1997.\n O Borussia Dortmund é reconhecido por desenvolver jovens talentos e proporcionar uma atmosfera única em seu estádio, o Signal Iduna Park.\n É considerado um dos clubes mais icônicos da Alemanha e da Europa.\n");
            printf("Edições Ganhas:\n");
            printf("1996-1997  2012-2013");
            break;

            case 15:
                textcolor(LIGHTRED);
                printf(R"EOF(



8888888888 8888888888 Y88b   d88P 8888888888 888b     d888  .d88888b.   .d88888b.  8888888b.  8888888b.
888        888         Y88b d88P  888        8888b   d8888 d88P" "Y88b d88P" "Y88b 888   Y88b 888  "Y88b
888        888          Y88o88P   888        88888b.d88888 888     888 888     888 888    888 888    888
8888888    8888888       Y888P    8888888    888Y88888P888 888     888 888     888 888   d88P 888    888
888        888            888     888        888 Y888P 888 888     888 888     888 8888888P"  888    888
888        888            888     888        888  Y8P  888 888     888 888     888 888 T88b   888    888
888        888            888     888        888   "   888 Y88b. .d88P Y88b. .d88P 888  T88b  888  .d88P
888        8888888888     888     8888888888 888       888  "Y88888P"   "Y88888P"  888   T88b 8888888P"





)EOF");
textcolor(WHITE);
            printf("Feyemoord\n");
            printf("Fundacao: 19 de julho de 1908\n");
            printf("Estadio:  Feyenoord Stadium\n");
            printf("Sobre:\n");
            printf("O Feyenoord é um proeminente clube de futebol holandês com sede em Roterdã.\n Fundado em 1908, o clube é conhecido por suas cores vermelho, branco e preto.\n O Feyenoord tem uma história rica e é um dos clubes mais bem-sucedidos da Holanda.\n O clube conquistou vários títulos nacionais e internacionais ao longo dos anos, incluindo a Liga dos Campeões da UEFA em 1969-1970 e a Copa da UEFA em 1973-1974.\n O Feyenoord tem uma base de fãs apaixonada e é considerado um dos clubes mais tradicionais e respeitados do futebol holandês.\n");
            printf("Edições Ganhas:\n");
            printf("1969-1970");
            break;

            case 16:
                textcolor(LIGHTCYAN);
                printf(R"EOF(



888b     d888        d8888 8888888b.   .d8888b.  8888888888 8888888 888      888      8888888888
8888b   d8888       d88888 888   Y88b d88P  Y88b 888          888   888      888      888
88888b.d88888      d88P888 888    888 Y88b.      888          888   888      888      888
888Y88888P888     d88P 888 888   d88P  "Y888b.   8888888      888   888      888      8888888
888 Y888P 888    d88P  888 8888888P"      "Y88b. 888          888   888      888      888
888  Y8P  888   d88P   888 888 T88b         "888 888          888   888      888      888
888   "   888  d8888888888 888  T88b  Y88b  d88P 888          888   888      888      888
888       888 d88P     888 888   T88b  "Y8888P"  8888888888 8888888 88888888 88888888 8888888888





)EOF");
textcolor(WHITE);
            printf("Marseille\n");
            printf("Fundacao: 31 de agosto de 1899\n");
            printf("Estadio:  Stade Vélodrome\n");
            printf("Sobre:\n");
            printf("O Marseille, também conhecido como Olympique de Marseille, é um famoso clube de futebol francês com sede em Marselha.\n Fundado em 1899, o clube é conhecido por suas cores azul e branca.\n O Marseille tem uma rica história e é um dos clubes mais bem-sucedidos da França.\n O clube conquistou vários títulos nacionais e internacionais, incluindo a Liga dos Campeões da UEFA em 1992-1993.\n O Marseille tem uma base de fãs apaixonada e é considerado um dos principais clubes do futebol francês.\n");
            printf("Edições Ganhas:\n");
            printf("1992-1993");
            break;

            case 17:
                textcolor(MAGENTA);
                printf(R"EOF(



       d8888  .d8888b. 88888888888 .d88888b.  888b    888      888     888 8888888 888      888             d8888
      d88888 d88P  Y88b    888    d88P" "Y88b 8888b   888      888     888   888   888      888            d88888
     d88P888 Y88b.         888    888     888 88888b  888      888     888   888   888      888           d88P888
    d88P 888  "Y888b.      888    888     888 888Y88b 888      Y88b   d88P   888   888      888          d88P 888
   d88P  888     "Y88b.    888    888     888 888 Y88b888       Y88b d88P    888   888      888         d88P  888
  d88P   888       "888    888    888     888 888  Y88888        Y88o88P     888   888      888        d88P   888
 d8888888888 Y88b  d88P    888    Y88b. .d88P 888   Y8888         Y888P      888   888      888       d8888888888
d88P     888  "Y8888P"     888     "Y88888P"  888    Y888          Y8P     8888888 88888888 88888888 d88P     888





)EOF");
textcolor(WHITE);
            printf("Aston Villa\n");
            printf("Fundacao: março de 1874\n");
            printf("Estadio: Villa Park\n");
            printf("Sobre:\n");
            printf("O Aston Villa é um conhecido clube de futebol inglês com sede na cidade de Birmingham.\n Fundado em 1874, o clube é conhecido por suas cores claret e blue.\n O Aston Villa possui uma história rica e é um dos clubes mais antigos e bem-sucedidos da Inglaterra.\n O clube conquistou vários títulos nacionais e internacionais ao longo dos anos, incluindo a Liga dos Campeões da UEFA em 1981-1982.\n O Aston Villa tem uma base de fãs leal e é considerado um clube tradicional e respeitado no futebol inglês.\n");
            printf("Edições Ganhas:\n");
            printf("1981-1982");
            break;

            case 18:
                textcolor(BLUE);
                printf(R"EOF(



888    888        d8888 888b     d888 888888b.   888     888 8888888b.   .d8888b.
888    888       d88888 8888b   d8888 888  "88b  888     888 888   Y88b d88P  Y88b
888    888      d88P888 88888b.d88888 888  .88P  888     888 888    888 888    888
8888888888     d88P 888 888Y88888P888 8888888K.  888     888 888   d88P 888
888    888    d88P  888 888 Y888P 888 888  "Y88b 888     888 8888888P"  888  88888
888    888   d88P   888 888  Y8P  888 888    888 888     888 888 T88b   888    888
888    888  d8888888888 888   "   888 888   d88P Y88b. .d88P 888  T88b  Y88b  d88P
888    888 d88P     888 888       888 8888888P"   "Y88888P"  888   T88b  "Y8888P88





)EOF");
textcolor(WHITE);
            printf("Hamburg\n");
            printf("Fundacao: 29 de setembro de 1887\n");
            printf("Estadio: Volksparkstadion\n");
            printf("Sobre:\n");
            printf("O Hamburgo SV, também conhecido como HSV, é um proeminente clube de futebol alemão com sede em Hamburgo.\n Fundado em 1887, o clube é conhecido por suas cores azul, branco e preto.\n O HSV é um dos clubes mais antigos da Alemanha e tem uma rica história no futebol alemão.\n O clube já conquistou vários títulos nacionais e internacionais, incluindo a Liga dos Campeões da UEFA em 1982-1983.\n O HSV tem uma base de fãs leal e é considerado uma das equipes mais tradicionais da Alemanha.\n");
            printf("Edições Ganhas:\n");
            printf("1982-1983");
            break;

            case 19:
                textcolor(LIGHTRED);
                printf(R"EOF(



 .d8888b.  8888888b.  888     888 8888888888 888b    888        d8888      8888888888P 888     888 8888888888 8888888888P 8888888b.        d8888
d88P  Y88b 888   Y88b 888     888 888        8888b   888       d88888            d88P  888     888 888              d88P  888  "Y88b      d88888
888    888 888    888 888     888 888        88888b  888      d88P888           d88P   888     888 888             d88P   888    888     d88P888
888        888   d88P Y88b   d88P 8888888    888Y88b 888     d88P 888          d88P    Y88b   d88P 8888888        d88P    888    888    d88P 888
888        8888888P"   Y88b d88P  888        888 Y88b888    d88P  888         d88P      Y88b d88P  888           d88P     888    888   d88P  888
888    888 888 T88b     Y88o88P   888        888  Y88888   d88P   888        d88P        Y88o88P   888          d88P      888    888  d88P   888
Y88b  d88P 888  T88b     Y888P    888        888   Y8888  d8888888888       d88P          Y888P    888         d88P       888  .d88P d8888888888
 "Y8888P"  888   T88b     Y8P     8888888888 888    Y888 d88P     888      d8888888888     Y8P     8888888888 d8888888888 8888888P" d88P     888





)EOF");
textcolor(WHITE);
            printf("Crvena Zvezda\n");
            printf("Fundacao: 4 de março de 1945\n");
            printf("Estadio:  Rajko Mitic Stadium\n");
            printf("Sobre:\n");
            printf("O Crvena Zvezda, também conhecido como Estrela Vermelha, é um famoso clube de futebol sérvio com sede em Belgrado.\n Fundado em 1945, o clube é conhecido por suas cores vermelho e branco.\n O Crvena Zvezda tem uma história de sucesso, tendo conquistado vários títulos nacionais e internacionais ao longo dos anos.\n O clube ganhou a Liga dos Campeões da UEFA em uma ocasião, em 1990-1991.\n O Crvena Zvezda tem uma base de fãs apaixonada e é considerado um dos clubes mais proeminentes da Sérvia e da região dos Balcãs.\n");
            printf("Edições Ganhas:\n");
            printf("1990-1991");
            break;

            case 20:
                textcolor(4);
                printf(R"EOF(



8888888888 .d8888b.   .d8888b.  888888b.
888       d88P  Y88b d88P  Y88b 888  "88b
888       888    888 Y88b.      888  .88P
8888888   888         "Y888b.   8888888K.
888       888            "Y88b. 888  "Y88b
888       888    888       "888 888    888
888       Y88b  d88P Y88b  d88P 888   d88P
888        "Y8888P"   "Y8888P"  8888888P"





)EOF");
textcolor(WHITE);
            printf("FCSB\n");
            printf("Fundacao: 7 de junho de 1947\n");
            printf("Estadio: The National Arena\n");
            printf("Sobre:\n");
            printf("O FCSB, anteriormente conhecido como Steaua Bucareste, é um clube de futebol romeno com sede em Bucareste. Fundado em 1947, o clube é conhecido por suas cores vermelho e azul.\n O FCSB tem uma história rica e é um dos clubes mais bem-sucedidos da Romênia.\n O clube conquistou vários títulos nacionais e internacionais, incluindo a Liga dos Campeões da UEFA em uma ocasião, em 1985-1986.\n O FCSB tem uma base de fãs apaixonada e é considerado um dos principais clubes do futebol romeno.\n");
            printf("Edições Ganhas:\n");
            printf("1985-1986");
            break;

            case 21:
                textcolor(12);
                printf(R"EOF(


8888888b.   .d8888b.  888     888
888   Y88b d88P  Y88b 888     888
888    888 Y88b.      888     888
888   d88P  "Y888b.   Y88b   d88P
8888888P"      "Y88b.  Y88b d88P
888              "888   Y88o88P
888        Y88b  d88P    Y888P
888         "Y8888P"      Y8P




)EOF");
textcolor(WHITE);
            printf("PSV\n");
            printf("Fundacao: 31 de agosto de 1913\n");
            printf("Estadio: Philips Stadion\n");
            printf("Sobre:\n");
            printf("O PSV, também conhecido como Philips Sport Vereniging, é um famoso clube de futebol holandês com sede em Eindhoven.\n Fundado em 1913, o clube é conhecido por suas cores vermelho e branco.\n O PSV possui uma história de sucesso, com vários títulos nacionais e internacionais em seu nome.\n O clube conquistou a Liga dos Campeões da UEFA em uma ocasião, em 1987-1988.\n O PSV tem uma base de fãs apaixonada e é considerado um dos principais clubes do futebol holandês.\n");
            printf("Edições Ganhas:\n");
            printf("1987-1988");
            break;

            case 22:
                 textcolor(10);
                printf(R"EOF(

 .d8888b.  8888888888 888    88888888888 8888888 .d8888b.
d88P  Y88b 888        888        888       888  d88P  Y88b
888    888 888        888        888       888  888    888
888        8888888    888        888       888  888
888        888        888        888       888  888
888    888 888        888        888       888  888    888
Y88b  d88P 888        888        888       888  Y88b  d88P
 "Y8888P"  8888888888 88888888   888     8888888 "Y8888P"




)EOF");
textcolor(WHITE);
            printf("Celtic\n");
            printf("Fundacao: 6 de novembro de 1887\n");
            printf("Estadio:  Celtic Park\n");
            printf("Sobre:\n");
            printf("O Celtic é um proeminente clube de futebol escocês com sede em Glasgow.\n Fundado em 1887, o clube é conhecido por suas cores verde e branca.\n O Celtic possui uma rica história e é um dos clubes mais bem-sucedidos da Escócia.\n O clube conquistou vários títulos nacionais e internacionais, incluindo a Liga dos Campeões da UEFA em uma ocasião, em 1966-1967.\n O Celtic tem uma base de fãs apaixonada e é conhecido por sua rivalidade com o Rangers, formando um dos maiores dérbis do futebol britânico.\n");
            printf("Edições Ganhas:\n");
            printf("1966-1967");
            break;

            case 23:
                textcolor(LIGHTCYAN);
                printf(R"EOF(

888b     d888        d8888 888b    888  .d8888b.  888    888 8888888888 .d8888b. 88888888888 8888888888 8888888b.        .d8888b. 8888888 88888888888 Y88b   d88P
8888b   d8888       d88888 8888b   888 d88P  Y88b 888    888 888       d88P  Y88b    888     888        888   Y88b      d88P  Y88b  888       888      Y88b d88P
88888b.d88888      d88P888 88888b  888 888    888 888    888 888       Y88b.         888     888        888    888      888    888  888       888       Y88o88P
888Y88888P888     d88P 888 888Y88b 888 888        8888888888 8888888    "Y888b.      888     8888888    888   d88P      888         888       888        Y888P
888 Y888P 888    d88P  888 888 Y88b888 888        888    888 888           "Y88b.    888     888        8888888P"       888         888       888         888
888  Y8P  888   d88P   888 888  Y88888 888    888 888    888 888             "888    888     888        888 T88b        888    888  888       888         888
888   "   888  d8888888888 888   Y8888 Y88b  d88P 888    888 888       Y88b  d88P    888     888        888  T88b       Y88b  d88P  888       888         888
888       888 d88P     888 888    Y888  "Y8888P"  888    888 8888888888 "Y8888P"     888     8888888888 888   T88b       "Y8888P" 8888888     888         888




)EOF");
textcolor(WHITE);
            printf("Manchester City\n");
            printf("Fundacao: 1880\n");
            printf("Estadio: Etihad Stadium\n");
            printf("Sobre:\n");
            printf("O Manchester City, também conhecido como Man City, é um proeminente clube de futebol inglês sediado em Manchester.\n Fundado em 1880, o clube é conhecido por suas cores celeste e branca.\n O Man City tem uma história marcada por altos e baixos, mas experimentou um grande crescimento nas últimas décadas.\n O clube conquistou vários títulos nacionais, incluindo a Premier League, e teve sucesso em competições europeias, incluindo a sua primeira Liga dos Campeões da UEFA em 2023.\n O Man City é reconhecido por seu estilo de jogo ofensivo e possui uma base de fãs leal.\n");
            printf("Edições Ganhas:\n");
            printf("2022-2023");
            break;

        default:
            printf("Codigo de clube invalido!\n");
    }
}

#endif // INFO_CLUBS_H_INCLUDED
