#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>  // Biblioteca para getch()
#include <windows.h>
#include <conio.c>
#include <locale.h>
#include "info_clubes.h"

#define MAX_USERS 20
#define MAX_NAME 50
#define MAX_PASSWORD 20
#define FILE_NAME "users.txt"

typedef struct
{
    char name[MAX_NAME];
    char password[MAX_PASSWORD];
} User;

User users[MAX_USERS];
int numUsers = 0;

// Fun��o para registrar um novo usu�rio
void registerUser()
{
    // Verifica se o limite m�ximo de usu�rios foi atingido
    if (numUsers >= MAX_USERS)
        {
            system("cls");
        printf("O limite m�ximo de usu�rios foi atingido.\n");
        return;
        }

    User newUser;
             textcolor(BLUE);
    printf(R"EOF(
                                                                               _____ _    _          __  __ _____ _____ ____  _   _  _____
                                                                              / ____| |  | |   /\   |  \/  |  __ \_   _/ __ \| \ | |/ ____|
                                                                             | |    | |__| |  /  \  | \  / | |__) || || |  | |  \| | (___
                                                                             | |    |  __  | / /\ \ | |\/| |  ___/ | || |  | | . ` |\___ \
                                                                             | |____| |  | |/ ____ \| |  | | |    _| || |__| | |\  |____) |
                                                                              \_____|_|  |_/_/    \_\_|  |_|_|   |_____\____/|_| \_|_____/

                                                           _____   ____          _____    _______ ____    _______ _    _ ______   ______ _____ _   _          _
                                                          |  __ \ / __ \   /\   |  __ \  |__   __/ __ \  |__   __| |  | |  ____| |  ____|_   _| \ | |   /\   | |
                                                          | |__) | |  | | /  \  | |  | |    | | | |  | |    | |  | |__| | |__    | |__    | | |  \| |  /  \  | |
                                                          |  _  /| |  | |/ /\ \ | |  | |    | | | |  | |    | |  |  __  |  __|   |  __|   | | | . ` | / /\ \ | |
                                                          | | \ \| |__| / ____ \| |__| |    | | | |__| |    | |  | |  | | |____  | |     _| |_| |\  |/ ____ \| |____
                                                          |_|  \_\\____/_/    \_\_____/     |_|  \____/     |_|  |_|  |_|______| |_|    |_____|_| \_/_/    \_\______|


)EOF");
textcolor(WHITE);
    printf("Digite o nome de usu�rio: ");
    scanf("%s", newUser.name);

    // Verifica se o nome de usu�rio j� existe
    for (int i = 0; i < numUsers; i++)
        {
        if (strcmp(users[i].name, newUser.name) == 0)
        {
            system("cls");
            printf("Nome de usu�rio j� existe. Tente novamente.\n");
            return;
        }
    }

    printf("Digite a senha: ");
    scanf("%s", newUser.password);

    users[numUsers] = newUser;
    numUsers++;

    // Salvar o usu�rio no arquivo
    FILE* file = fopen(FILE_NAME, "a");
    if (file != NULL)
    {
        fprintf(file, "%s %s\n", newUser.name, newUser.password);
        fclose(file);
    }
system("cls");
    printf("Registro conclu�do com sucesso.\n");
}

// Fun��o para carregar os usu�rios do arquivo
void loadUsers()
{
    FILE* file = fopen(FILE_NAME, "r");
    if (file != NULL)
        {
        char name[MAX_NAME];
        char password[MAX_PASSWORD];

        while (fscanf(file, "%s %s\n", name, password) == 2)
            {
            User newUser;
            strcpy(newUser.name, name);
            strcpy(newUser.password, password);
            users[numUsers] = newUser;
            numUsers++;
        }

        fclose(file);
    }
}

// Fun��o para realizar o login do usu�rio
void login()
{
    char name[MAX_NAME];
    char password[MAX_PASSWORD];
             textcolor(BLUE);
    printf(R"EOF(
                                                                               _____ _    _          __  __ _____ _____ ____  _   _  _____
                                                                              / ____| |  | |   /\   |  \/  |  __ \_   _/ __ \| \ | |/ ____|
                                                                             | |    | |__| |  /  \  | \  / | |__) || || |  | |  \| | (___
                                                                             | |    |  __  | / /\ \ | |\/| |  ___/ | || |  | | . ` |\___ \
                                                                             | |____| |  | |/ ____ \| |  | | |    _| || |__| | |\  |____) |
                                                                              \_____|_|  |_/_/    \_\_|  |_|_|   |_____\____/|_| \_|_____/

                                                           _____   ____          _____    _______ ____    _______ _    _ ______   ______ _____ _   _          _
                                                          |  __ \ / __ \   /\   |  __ \  |__   __/ __ \  |__   __| |  | |  ____| |  ____|_   _| \ | |   /\   | |
                                                          | |__) | |  | | /  \  | |  | |    | | | |  | |    | |  | |__| | |__    | |__    | | |  \| |  /  \  | |
                                                          |  _  /| |  | |/ /\ \ | |  | |    | | | |  | |    | |  |  __  |  __|   |  __|   | | | . ` | / /\ \ | |
                                                          | | \ \| |__| / ____ \| |__| |    | | | |__| |    | |  | |  | | |____  | |     _| |_| |\  |/ ____ \| |____
                                                          |_|  \_\\____/_/    \_\_____/     |_|  \____/     |_|  |_|  |_|______| |_|    |_____|_| \_/_/    \_\______|


)EOF");
textcolor(WHITE);

    printf("Digite o nome de usu�rio: ");
    scanf("%s", name);

    printf("Digite a senha: ");
    scanf("%s", password);
    system("cls");

    // Verifica se o nome de usu�rio e senha correspondem a um usu�rio registrado
    for (int i = 0; i < numUsers; i++)
    {
        if (strcmp(users[i].name, name) == 0 && strcmp(users[i].password, password) == 0)
            {
                textcolor(BLUE);
    printf(R"EOF(
                                                                               _____ _    _          __  __ _____ _____ ____  _   _  _____
                                                                              / ____| |  | |   /\   |  \/  |  __ \_   _/ __ \| \ | |/ ____|
                                                                             | |    | |__| |  /  \  | \  / | |__) || || |  | |  \| | (___
                                                                             | |    |  __  | / /\ \ | |\/| |  ___/ | || |  | | . ` |\___ \
                                                                             | |____| |  | |/ ____ \| |  | | |    _| || |__| | |\  |____) |
                                                                              \_____|_|  |_/_/    \_\_|  |_|_|   |_____\____/|_| \_|_____/

                                                           _____   ____          _____    _______ ____    _______ _    _ ______   ______ _____ _   _          _
                                                          |  __ \ / __ \   /\   |  __ \  |__   __/ __ \  |__   __| |  | |  ____| |  ____|_   _| \ | |   /\   | |
                                                          | |__) | |  | | /  \  | |  | |    | | | |  | |    | |  | |__| | |__    | |__    | | |  \| |  /  \  | |
                                                          |  _  /| |  | |/ /\ \ | |  | |    | | | |  | |    | |  |  __  |  __|   |  __|   | | | . ` | / /\ \ | |
                                                          | | \ \| |__| / ____ \| |__| |    | | | |__| |    | |  | |  | | |____  | |     _| |_| |\  |/ ____ \| |____
                                                          |_|  \_\\____/_/    \_\_____/     |_|  \____/     |_|  |_|  |_|______| |_|    |_____|_| \_/_/    \_\______|


)EOF");
textcolor(WHITE);

            printf("Login bem-sucedido. Bem-vindo, %s!\n", users[i].name);

            char menuChoice;
            do {
                printf("\n==== Menu ====\n");
                printf("1. Champions 22/23\n");
                printf("2. Informa��es dos Clubes\n");
                printf("3. Criar uma Champions\n");
                printf("4. Hist�rico\n");
                printf("0. Sair da Conta\n");
                printf("Escolha uma op��o: ");
                scanf(" %c", &menuChoice);
                fflush(stdin);
                system("cls");

                switch (menuChoice)
                {
                    case '1':
                        printf("Executando Champions 22/23.\n");
                                        textcolor(BLUE);
    printf(R"EOF(

                                                     ______   __                                          __                                       ______    ______         __  ______    ______
                                                    /      \ /  |                                        /  |                                     /      \  /      \       /  |/      \  /      \
                                                   /$$$$$$  |$$ |____    ______   _____  ____    ______  $$/   ______   _______    _______       /$$$$$$  |/$$$$$$  |     /$$//$$$$$$  |/$$$$$$  |
                                                   $$ |  $$/ $$      \  /      \ /     \/    \  /      \ /  | /      \ /       \  /       |      $$____$$ |$$____$$ |    /$$/ $$____$$ |$$ ___$$ |
                                                   $$ |      $$$$$$$  | $$$$$$  |$$$$$$ $$$$  |/$$$$$$  |$$ |/$$$$$$  |$$$$$$$  |/$$$$$$$/        /    $$/  /    $$/    /$$/   /    $$/   /   $$<
                                                   $$ |   __ $$ |  $$ | /    $$ |$$ | $$ | $$ |$$ |  $$ |$$ |$$ |  $$ |$$ |  $$ |$$      \       /$$$$$$/  /$$$$$$/    /$$/   /$$$$$$/   _$$$$$  |
                                                   $$ \__/  |$$ |  $$ |/$$$$$$$ |$$ | $$ | $$ |$$ |__$$ |$$ |$$ \__$$ |$$ |  $$ | $$$$$$  |      $$ |_____ $$ |_____  /$$/    $$ |_____ /  \__$$ |
                                                   $$    $$/ $$ |  $$ |$$    $$ |$$ | $$ | $$ |$$    $$/ $$ |$$    $$/ $$ |  $$ |/     $$/       $$       |$$       |/$$/     $$       |$$    $$/
                                                    $$$$$$/  $$/   $$/  $$$$$$$/ $$/  $$/  $$/ $$$$$$$/  $$/  $$$$$$/  $$/   $$/ $$$$$$$/        $$$$$$$$/ $$$$$$$$/ $$/      $$$$$$$$/  $$$$$$/
                                                                                               $$ |
                                                                                               $$ |
                                                                                               $$/


)EOF");
textcolor(WHITE);
                        printf(R"EOF(
                                  ===== Oitavas de Final =====     |     ===== Quartos de Final =====     |     =====    SemiFinal    =====     |     =====      Final      =====
                                        PSG   -   Bayern Munich    |          Napoli   -   Milan          |        Inter    -   Milan           |       Inter  0  -  1  Man City
                                         (Agg. 0-3)                |              (Agg. 1-2)              |            (Agg. 3-0)               |
                                Real Madrid   -   Liverpool        |     Real Madrid   -   Chelsea        |   Real Madrid   -   Man City        |
                                         (Agg. 6-2)                |              (Agg. 4-0)              |            (Agg. 1-5)               |
                                   Man City   -   Leipzig          |        Man City   -   Bayern Munich  |                                     |
                                         (Agg. 8-1)                |              (Agg. 4-1)              |                                     |
                                      Porto   -   Inter            |         Benfica   -   Inter          |                                     |
                                         (Agg. 0-1)                |              (Agg. 3-5)              |                                     |
                                      Milan   -   Tottenham        |                                      |                                     |
                                         (Agg. 1-0)                |                                      |                                     |
                                     Napoli   -   Frankfurt        |                                      |                                     |
                                         (Agg. 5-0)                |                                      |                                     |
                                    Benfica   -   Club Brugge      |                                      |                                     |
                                         (Agg. 7-1)                |                                      |                                     |
                                    Chelsea   -   Dortmund         |                                      |                                     |
                                         (Agg. 1-2)                |                                      |                                     |







                                                               __  ______    _   __   __________________  __   _________    ________  ________
                                                              /  |/  /   |  / | / /  / ____/  _/_  __/\ \/ /  /  _/ ___/   /_  __/ / / / ____/
                                                             / /|_/ / /| | /  |/ /  / /    / /  / /    \  /   / / \__ \     / / / /_/ / __/
                                                            / /  / / ___ |/ /|  /  / /____/ /  / /     / /  _/ / ___/ /    / / / __  / /___
                                                           /_/__/_/_/_ |_/_/_|_/ __\____/___/ /_/_____/_/  /___//____/ ___/_/ /_/_/_/_____/___ ____  ____  ________
                                                          / ____/ / / /   |  /  |/  / __ \/  _/ __ \/ | / /  / __ \/ ____/  / ____/ / / / __ \/ __ \/ __ \/ ____/ /
                                                         / /   / /_/ / /| | / /|_/ / /_/ // // / / /  |/ /  / / / / /_     / __/ / / / / /_/ / / / / /_/ / __/ / /
                                                        / /___/ __  / ___ |/ /  / / ____// // /_/ / /|  /  / /_/ / __/    / /___/ /_/ / _, _/ /_/ / ____/ /___/_/
                                                        \____/_/ /_/_/  |_/_/  /_/_/   /___/\____/_/ |_/   \____/_/      /_____/\____/_/ |_|\____/_/   /_____(_)

)EOF");
printf("\n");

                        break;
                    case '2':
                        printf("Executando Informa��es de Clubes.\n");
                        printf("Lista de clubes com hist�rico na UEFA Champions League:\n");
                         printf("\n");
                        printf("1� - Real Madrid - 14 T�tulos da UCL\n");
                         printf("\n");
                        printf("2� - Milan - 7 T�tulos da UCL\n");
                         printf("\n");
                        printf("3� - Bayern de Munique - 6 T�tulos da UCL\n");
                         printf("\n");
                        printf("4� - Liverpool - 6 T�tulos da UCL\n");
                         printf("\n");
                        printf("5� - Barcelona - 5 T�tulos da UCL\n");
                         printf("\n");
                        printf("6� - Ajax - 4 T�tulos da UCL\n");
                         printf("\n");
                        printf("7� - Manchester United - 3 T�tulos da UCL\n");
                         printf("\n");
                        printf("8� - Inter de Mil�o - 3 T�tulos da UCL\n");
                         printf("\n");
                        printf("9� - Chealsea - 2 T�tulos da UCL\n");
                         printf("\n");
                        printf("10� - Nottingham Forest - 2 T�tulos da UCL\n");
                         printf("\n");
                        printf("11� - Benfica - 2 T�tulos da UCL\n");
                         printf("\n");
                        printf("12� - Juventus - 2 T�tulos da UCL\n");
                         printf("\n");
                        printf("13� - Porto - 2 T�tulos da UCL\n");
                         printf("\n");
                        printf("14� - Borussia Dortmund - 1 T�tulos da UCL\n");
                         printf("\n");
                        printf("15� - Feyemoord - 1 T�tulos da UCL\n");
                         printf("\n");
                        printf("16� - Marseille - 1 T�tulos da UCL\n");
                         printf("\n");
                        printf("17� - Aston Villa - 1 T�tulos da UCL\n");
                         printf("\n");
                        printf("18� - Hamburg - 1 T�tulos da UCL\n");
                         printf("\n");
                        printf("19� - Crvena Zvezda - 1 T�tulos da UCL\n");
                         printf("\n");
                        printf("20� - FCSB - 1 T�tulos da UCL\n");
                         printf("\n");
                        printf("21� - PSV - 1 T�tulos da UCL\n");
                        printf("\n");
                        printf("22� - Celtic - 1 T�tulos da UCL\n");
                        printf("\n");
                        printf("23� - Manchester City - 1 T�tulos da UCL\n");
                        scanf("%i",&info);

                        infoclub(info);
                        break;
                    case '3':
                        printf("Executando Criar Champions league.\n");
                        break;
                    case '4':
                        printf("Executando Hist�rico.\n");
                        break;
                    case '0':
                        printf("Voltando ao menu de Login.\n");
                        break;
                    default:
                        printf("Op��o inv�lida. Tente novamente.\n");
                        break;
                }

                printf("\n");
            } while (menuChoice != '0');

            return;
        }
    }

    printf("Falha no login. Nome de usu�rio ou senha incorretos.\n");
}

int main() {
    //fullscreen
    keybd_event(VK_MENU  , 0x36, 0, 0);
    keybd_event(VK_RETURN, 0x1C, 0, 0);
    keybd_event(VK_RETURN, 0x1C, KEYEVENTF_KEYUP, 0);
    keybd_event(VK_MENU  , 0x38, KEYEVENTF_KEYUP, 0);



setlocale(LC_ALL,"portuguese");

    char choice;
    int info;

    // Carregar os usu�rios do arquivo
    loadUsers();

    // Exibir a p�gina inicial
    textcolor(BLUE);
    printf(R"EOF(
                                                                               _____ _    _          __  __ _____ _____ ____  _   _  _____
                                                                              / ____| |  | |   /\   |  \/  |  __ \_   _/ __ \| \ | |/ ____|
                                                                             | |    | |__| |  /  \  | \  / | |__) || || |  | |  \| | (___
                                                                             | |    |  __  | / /\ \ | |\/| |  ___/ | || |  | | . ` |\___ \
                                                                             | |____| |  | |/ ____ \| |  | | |    _| || |__| | |\  |____) |
                                                                              \_____|_|  |_/_/    \_\_|  |_|_|   |_____\____/|_| \_|_____/

                                                           _____   ____          _____    _______ ____    _______ _    _ ______   ______ _____ _   _          _
                                                          |  __ \ / __ \   /\   |  __ \  |__   __/ __ \  |__   __| |  | |  ____| |  ____|_   _| \ | |   /\   | |
                                                          | |__) | |  | | /  \  | |  | |    | | | |  | |    | |  | |__| | |__    | |__    | | |  \| |  /  \  | |
                                                          |  _  /| |  | |/ /\ \ | |  | |    | | | |  | |    | |  |  __  |  __|   |  __|   | | | . ` | / /\ \ | |
                                                          | | \ \| |__| / ____ \| |__| |    | | | |__| |    | |  | |  | | |____  | |     _| |_| |\  |/ ____ \| |____
                                                          |_|  \_\\____/_/    \_\_____/     |_|  \____/     |_|  |_|  |_|______| |_|    |_____|_| \_/_/    \_\______|


)EOF");
textcolor(WHITE);

    printf("Pressione qualquer tecla para iniciar o programa ou 2 para sair.\n");
    choice = getch();
    system("cls");

    if (choice == '2')
        {

        printf("Saindo...\n");

    }

    do {
            textcolor(BLUE);
    printf(R"EOF(
                                                                               _____ _    _          __  __ _____ _____ ____  _   _  _____
                                                                              / ____| |  | |   /\   |  \/  |  __ \_   _/ __ \| \ | |/ ____|
                                                                             | |    | |__| |  /  \  | \  / | |__) || || |  | |  \| | (___
                                                                             | |    |  __  | / /\ \ | |\/| |  ___/ | || |  | | . ` |\___ \
                                                                             | |____| |  | |/ ____ \| |  | | |    _| || |__| | |\  |____) |
                                                                              \_____|_|  |_/_/    \_\_|  |_|_|   |_____\____/|_| \_|_____/

                                                           _____   ____          _____    _______ ____    _______ _    _ ______   ______ _____ _   _          _
                                                          |  __ \ / __ \   /\   |  __ \  |__   __/ __ \  |__   __| |  | |  ____| |  ____|_   _| \ | |   /\   | |
                                                          | |__) | |  | | /  \  | |  | |    | | | |  | |    | |  | |__| | |__    | |__    | | |  \| |  /  \  | |
                                                          |  _  /| |  | |/ /\ \ | |  | |    | | | |  | |    | |  |  __  |  __|   |  __|   | | | . ` | / /\ \ | |
                                                          | | \ \| |__| / ____ \| |__| |    | | | |__| |    | |  | |  | | |____  | |     _| |_| |\  |/ ____ \| |____
                                                          |_|  \_\\____/_/    \_\_____/     |_|  \____/     |_|  |_|  |_|______| |_|    |_____|_| \_/_/    \_\______|


)EOF");
textcolor(WHITE);
        printf("\n==== Menu ====\n");
        printf("1. Registrar novo usu�rio\n");
        printf("2. Login\n");
        printf("0. Sair\n");
        printf("Escolha uma op��o: ");
        scanf(" %c", &choice);
        fflush(stdin);

        switch (choice)
        {
            case '1':
                system("cls");
                registerUser();
                break;
            case '2':
                system("cls");
                login();
                break;
            case '0':
                system("cls");
                printf("Saindo...\n");
                break;
            default:
                system("cls");
                printf("Op��o inv�lida. Tente novamente.\n");
                break;
        }

        printf("\n");
    } while (choice != '0');

    return 0;
}
