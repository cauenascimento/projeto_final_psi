#ifndef INFO_CLUBS_H_INCLUDED
#define INFO_CLUBS_H_INCLUDED

void infoclub(int info)

{
    switch(info)
    {
        case 1:
            printf("Real Madrid:\n");
            printf("Fundacao: 6 de março de 1902\n");
            printf("Estadio: Santiago Bernabéu\n");
            printf("Sobre:\n");
            printf("O Real Madrid é um famoso clube de futebol espanhol sediado em Madrid. Fundado em 1902, é um dos clubes mais bem-sucedidos da história, com um extenso número de títulos nacionais e internacionais.\n Conhecido por sua camisa branca icônica, o Real Madrid conquistou a Liga dos Campeões da UEFA 14 vezes e é reconhecido por ter contado com grandes jogadores, como Cristiano Ronaldo e Di Stéfano, ao longo de sua história.\n É também um dos clubes mais valiosos e populares do mundo.\n");
            printf("Edições Ganhas:\n");
            printf("1955-56  1956-57  1957-58  1958-59  1959-60  1965-66  1997-98\n1999-00  2001-02  2013-14  2015-16  2016-17  2017-18  2021-22");
            break;
        case 2:
            printf("AC Milan\n");
            printf("Fundacao: 16 de dezembro de 1899\n");
            printf("Estadio: San Siro\n");
            printf("Sobre:\n");
            printf("O AC Milan é um renomado clube de futebol italiano com sede em Milão.\n Fundado em 1899, é um dos clubes mais tradicionais do país. O AC Milan é conhecido por suas cores vermelho e preto e tem uma história rica em conquistas, incluindo títulos nacionais e internacionais.\n O clube já venceu a Liga dos Campeões da UEFA 7 vezes e possui uma base de fãs apaixonada em todo o mundo.\n Ao longo dos anos, o AC Milan teve jogadores lendários, como Paolo Maldini e Marco van Basten, contribuindo para sua reputação como um dos principais clubes do futebol italiano e europeu.\n")
            printf("Edições Ganhas:\n");
             printf("1962–63  1968–69  1988–89  1989–90\n1993–94  2002–03  2006–07");
            break;
        case 3:
            printf("Bayern Munich\n");
            printf("Fundacao: 27 de fevereiro de 1900\n");
            printf("Estadio: Allianz Arena\n");
            printf("Sobre:\n");
            printf("O Bayern de Munique (Bayern Munich) é um famoso clube de futebol alemão baseado em Munique.\n Fundado em 1900, é um dos clubes mais bem-sucedidos da Alemanha e do mundo.\n O Bayern de Munique é conhecido por suas cores vermelho e branco, e conquistou inúmeros títulos nacionais e internacionais ao longo de sua história.\n O clube é reconhecido por ter contado com jogadores lendários, como Franz Beckenbauer e Gerd Müller.\n Além disso, o Bayern de Munique é conhecido por seu estádio icônico, a Allianz Arena, e por ser um dos clubes mais valiosos e bem administrados do futebol mundial.");
            printf("Edições Ganhas:\n");
            printf("1973-1974  1974-1975  1975-1976 \n 2000-2001  2012-2013  2019-2020");
            break;

            case 4:
            printf("Liverpool\n");
            printf("Fundacao:  3 de junho de 1892\n");
            printf("Estadio: Anfield\n");
            printf("Sobre:\n");
            printf("O Liverpool é um proeminente clube de futebol inglês com sede na cidade de Liverpool.\n Fundado em 1892, o clube é conhecido por suas cores vermelho e branco.\n O Liverpool possui uma história rica em conquistas, com muitos títulos nacionais e internacionais.\n O clube ganhou a Liga dos Campeões da UEFA em 6 ocasiões e é reconhecido por sua atmosfera apaixonada no estádio Anfield.\n O Liverpool tem uma base de fãs leal e é famoso por seus momentos memoráveis ​​e jogadores lendários, como Steven Gerrard e Kenny Dalglish.\n É um dos clubes mais icônicos do futebol inglês e europeu.");
            printf("Edições Ganhas:\n");
            printf("1976-1977  1977-1978  1980-1981 \n 1983-1984  2004-2005  2018-2019");
            break;


            case 5:
            printf("Barcelona\n");
            printf("Fundacao: 29 de novembro de 1899\n");
            printf("Estadio: Spotify Camp Nou\n");
            printf("Sobre:\n");
            printf("O FC Barcelona, também conhecido como Barça, é um renomado clube de futebol espanhol sediado em Barcelona.\h Fundado em 1899, o clube é reconhecido por suas cores azul e grená.\h O Barcelona é famoso por seu estilo de jogo característico, baseado na posse de bola e na habilidade técnica de seus jogadores.\h O clube conquistou inúmeros títulos nacionais e internacionais, incluindo a Liga dos Campeões da UEFA.\h O Barcelona é associado a grandes jogadores, como Lionel Messi, Xavi Hernández e Andrés Iniesta, e é considerado um dos clubes mais prestigiosos e bem-sucedidos do futebol mundial.");
            printf("Edições Ganhas:\n");
            printf("1991-1992  2005-2006  2008-2009 \n 2010-2011  2014-2015");
            break;

            case 6:
            printf("Ajax\n");
            printf("Fundacao: 18 de março de 1900\n");
            printf("Estadio: Johan Cruijff Arena\n");
            printf("Sobre:\n");
            printf("O Ajax é um conhecido clube de futebol holandês com sede em Amsterdã.\n Fundado em 1900, o Ajax é reconhecido por suas cores vermelho e branco.\n O clube possui uma história de sucesso, tendo conquistado vários títulos nacionais e internacionais, incluindo a Liga dos Campeões da UEFA.\n O Ajax é conhecido por seu estilo de jogo ofensivo e por desenvolver jovens talentos em sua famosa academia de futebol.\n Ao longo dos anos, o clube produziu jogadores lendários, como Johan Cruyff e Marco van Basten, e continua sendo um dos clubes mais proeminentes da Holanda e da Europa.");
            printf("Edições Ganhas:\n");
            printf("1970–71  1971–72 \n 1972–73  1994–95");
            break;

            case 7:
            printf("Manchester United\n");
            printf("Fundacao: 1878\n");
            printf("Estadio: Old Trashford\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 8:
            printf("Inter de Milão\n");
            printf("Fundacao: 9 de março de 1908\n");
            printf("Estadio: Giuseppe Meazza\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 9:
            printf("Chelsea\n");
            printf("Fundacao: 10 de março de 1905\n");
            printf("Estadio: Stamford Bridge\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 10:
            printf("Nottingham Forest\n");
            printf("Fundacao: 1865\n");
            printf("Estadio: City Ground\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 11:
            printf("Benfica\n");
            printf("Fundacao: 28 de fevereiro de 1904\n");
            printf("Estadio: Estádio da Luz\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 12:
            printf("Juventus\n");
            printf("Fundacao: 1 de novembro de 1897\n");
            printf("Estadio: Juventus Stadium\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 13:
            printf("Porto\n");
            printf("Fundacao: 28 de setembro de 1893\n");
            printf("Estadio:  Estádio do Dragão\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 14:
            printf("Borussia Dortmund\n");
            printf("Fundacao: 19 de dezembro de 1909\n");
            printf("Estadio:  Signal Iduna Park\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 15:
            printf("Feyemoord\n");
            printf("Fundacao: 19 de julho de 1908\n");
            printf("Estadio:  Feyenoord Stadium\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 16:
            printf("Marseille\n");
            printf("Fundacao: 31 de agosto de 1899\n");
            printf("Estadio:  Stade Vélodrome\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 17:
            printf("Aston Villa\n");
            printf("Fundacao: março de 1874\n");
            printf("Estadio: Villa Park\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 18:
            printf("Hamburg\n");
            printf("Fundacao: 29 de setembro de 1887\n");
            printf("Estadio: Volksparkstadion\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 19:
            printf("Crvena Zvezda\n");
            printf("Fundacao: 4 de março de 1945\n");
            printf("Estadio:  Rajko Mitic Stadium\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 20:
            printf("FCSB\n");
            printf("Fundacao: 7 de junho de 1947\n");
            printf("Estadio: The National Arena\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 21:
            printf("PSV\n");
            printf("Fundacao: 31 de agosto de 1913\n");
            printf("Estadio: Philips Stadion\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 22:
            printf("Celtic\n");
            printf("Fundacao: 6 de novembro de 1887\n");
            printf("Estadio:  Celtic Park\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

            case 23:
            printf("Manchester City\n");
            printf("Fundacao: 1880\n");
            printf("Estadio: Etihad Stadium\n");
            printf("Sobre:\n");
            printf("");
            printf("Edições Ganhas:\n");
            printf("");
            break;

        default:
            printf("Codigo de clube invalido!\n");
    }
}

#endif // INFO_CLUBS_H_INCLUDED
