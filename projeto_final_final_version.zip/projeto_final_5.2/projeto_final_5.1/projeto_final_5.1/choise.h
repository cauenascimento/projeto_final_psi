#ifndef CHOISE_H_INCLUDED
#define CHOISE_H_INCLUDED

void esc(int cham)
{
    int chamm;
  printf("=== ESCOLHA O MODO DE JOGO ===\n");
  printf("1 - Champions Reais\n");
  printf("2 - Criar a sua pr�pria champions\n");
  scanf("%i",&cham);
  switch (cham)


}

#endif // CHOISE_H_INCLUDED
