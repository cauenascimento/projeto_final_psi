#ifndef CREATE_CHAMP_H_INCLUDED
#define CREATE_CHAMP_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NUM_CLUBES 16

// Estrutura para representar um clube
typedef struct {
    char nome[50];
} Clube;

// Fun��o para realizar um jogo entre dois clubes e determinar o vencedor
int realizarJogo(Clube clubeA, Clube clubeB) {
    int resultado;

    printf("Resultado do jogo entre %s e %s:\n", clubeA.nome, clubeB.nome);
    printf("Digite 1 para vit�ria de %s ou 2 para vit�ria de %s: ", clubeA.nome, clubeB.nome);
    scanf("%d", &resultado);

    return resultado;

#endif // CREATE_CHAMP_H_INCLUDED
