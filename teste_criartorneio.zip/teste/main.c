#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NUM_CLUBES 16
#define MAX_NOME_CLUBE 50

// Estrutura para representar um clube
struct Clube {
    char nome[MAX_NOME_CLUBE];
};

// Fun��o para realizar um jogo entre dois clubes e determinar o vencedor
int realizarJogo(struct Clube clubeA, struct Clube clubeB) {
    int resultado;

    printf("Resultado do jogo entre %s e %s:\n", clubeA.nome, clubeB.nome);
    printf("Digite 1 para vit�ria de %s ou 2 para vit�ria de %s: ", clubeA.nome, clubeB.nome);
    scanf("%d", &resultado);

    return resultado;
}

int main() {
    struct Clube clubes[NUM_CLUBES];

    // Preenchendo os nomes dos clubes
    for (int i = 0; i < NUM_CLUBES; i++) {
        printf("Digite o nome do clube %d: ", i + 1);
        fgets(clubes[i].nome, MAX_NOME_CLUBE, stdin);

    }

    // Fase de Oitavas de Final
    for (int i = 0; i < NUM_CLUBES / 2; i++) {
        struct Clube clubeA = clubes[i];
        struct Clube clubeB = clubes[NUM_CLUBES - 1 - i];

        int vencedor = realizarJogo(clubeA, clubeB);

        clubes[i] = vencedor == 1 ? clubeA : clubeB;
    }

    // Fase de Quartas de Final
    for (int i = 0; i < NUM_CLUBES / 4; i++) {
        struct Clube clubeA = clubes[i];
        struct Clube clubeB = clubes[NUM_CLUBES / 2 - 1 - i];

        int vencedor = realizarJogo(clubeA, clubeB);

        clubes[i] = vencedor == 1 ? clubeA : clubeB;
    }

    // Fase de Semifinal
    for (int i = 0; i < NUM_CLUBES / 8; i++) {
        struct Clube clubeA = clubes[i];
        struct Clube clubeB = clubes[NUM_CLUBES / 4 - 1 - i];

        int vencedor = realizarJogo(clubeA, clubeB);

        clubes[i] = vencedor == 1 ? clubeA : clubeB;
    }

    // Fase Final
    struct Clube clubeA = clubes[0];
    struct Clube clubeB = clubes[NUM_CLUBES / 8 - 1];

    int vencedor = realizarJogo(clubeA, clubeB);

    struct Clube campeao = vencedor == 1 ? clubeA : clubeB;

    printf("\nO clube campe�o �: %s\n", campeao.nome);

    return 0;
}
